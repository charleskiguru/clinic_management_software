﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace CLINIC_MAGEMENT_SOFTWARE
{
    public partial class MANAGE_PATIENTS : Form
    {
        static string conString = "server=localhost;database=hospital;Uid=root;Password=;";
        MySqlConnection connection = new MySqlConnection(conString);
        MySqlCommand cmd;
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        MySqlDataReader dr;
        MySqlDataAdapter adapter;
        public MANAGE_PATIENTS()
        {
            InitializeComponent();
            retrieve();
            dateTimePicker2.Enabled = false;
        }
        private void retrieve()
        {

            MySqlCommand cmd = new MySqlCommand("SELECT * FROM patients;", connection);
            try
            {
                adapter = new MySqlDataAdapter(cmd);
                adapter.SelectCommand = cmd;
                dt = new DataTable();
                adapter.Fill(dt);
                BindingSource bs = new BindingSource();

                bs.DataSource = dt;
                dataGridView2.DataSource = bs;
                adapter.Update(dt);
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }

        }
        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void textAge_KeyPress(object sender, KeyPressEventArgs e)
        {

        }

        private void textPhone_KeyPress(object sender, KeyPressEventArgs e)
        {

        }

        private void button1refresh_Click(object sender, EventArgs e)
        {

        }

        private void button3Print_Click(object sender, EventArgs e)
        {

        }

        private void button2Delete_Click(object sender, EventArgs e)
        {

        }

        private void button1Update_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView2_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {

        }

        private void dataGridView2_MouseClick(object sender, MouseEventArgs e)
        {

        }
        private void update(int patient_Id, string fullname, string phone,  string county, string gender, string date_of_birth, string blood_group)
        {
            string sql = "UPDATE patients SET fullname='" + fullname + " ',phone= '" + phone + "',county='" + county + "', gender='" + gender + "',date_of_birth='" + date_of_birth + "',blood_group='" + blood_group + "' WHERE patient_Id=" + patient_Id + "";
            cmd = new MySqlCommand(sql, connection);

            try
            {
                connection.Open();
                adapter = new MySqlDataAdapter(cmd);
                adapter.UpdateCommand = connection.CreateCommand();
                adapter.UpdateCommand.CommandText = sql;

                if (MessageBox.Show("Do you want to update this patients' details??", "confirmation message", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    if (adapter.UpdateCommand.ExecuteNonQuery() > 0)
                    {
                        MessageBox.Show("Succesfully Updated");
                        clearText();


                    }
                }

                else
                {
                    clearText();
                }
                connection.Close();

                retrieve();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                connection.Close();
            }
        }
        private void button1Update_Click_1(object sender, EventArgs e)
        {
            if (textName.Text == "" || textPhone.Text == "" || comboGender.Text == "" || comboCounty.Text == "" ||  dateTimePicker2.Text == "" || comboBox2BLOOD.Text == "")
            {
                MessageBox.Show("Select a row to be updated!!!", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                string selected = dataGridView2.SelectedRows[0].Cells[0].Value.ToString();
                int patient_Id = Convert.ToInt32(selected);

                update(patient_Id, textName.Text, textPhone.Text,  comboCounty.Text, comboGender.Text, dateTimePicker2.Text, comboBox2BLOOD.Text);
            }
        }
        private void delete(int patient_Id)
        {
            string sql = "DELETE FROM patients WHERE patient_Id=" + patient_Id + "";
            try
            {
                connection.Open();
                cmd = new MySqlCommand(sql, connection);
                adapter = new MySqlDataAdapter(cmd);
                adapter.DeleteCommand = connection.CreateCommand();
                adapter.DeleteCommand.CommandText = sql;

                if (MessageBox.Show("Want to delete this patients details from database??", "confirmation messsage", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) == DialogResult.OK)
                {
                    if (adapter.DeleteCommand.ExecuteNonQuery() > 0)
                    {
                        MessageBox.Show("Seccesfully deleted");
                        clearText();

                    }
                }
                else
                {
                    clearText();
                }
                connection.Close();
                retrieve();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                connection.Close();

            }
        }
        private void button2Delete_Click_1(object sender, EventArgs e)
        {
            if (textName.Text == "" || textPhone.Text == "" || comboGender.Text == "" || comboCounty.Text == ""  || dateTimePicker2.Text == "" || comboBox2BLOOD.Text == "")
            {
                MessageBox.Show("Select a row to be deleted", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
            else
            {
                string selected = dataGridView2.SelectedRows[0].Cells[0].Value.ToString();
                int patient_Id = Convert.ToInt32(selected);
                delete(patient_Id);

            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            DataView DV = new DataView(dt);
            DV.RowFilter = string.Format("fullname LIKE'%{0}'", textBox1.Text.ToString());

            dataGridView2.DataSource = DV;

        }

        private void dataGridView2_MouseCaptureChanged(object sender, EventArgs e)
        {
            textId.Text = dataGridView2.SelectedRows[0].Cells[0].Value.ToString();
            textName.Text = dataGridView2.SelectedRows[0].Cells[1].Value.ToString();
            textPhone.Text = dataGridView2.SelectedRows[0].Cells[2].Value.ToString();
            
            comboCounty.Text = dataGridView2.SelectedRows[0].Cells[3].Value.ToString();
            comboGender.Text = dataGridView2.SelectedRows[0].Cells[4].Value.ToString();
            dateTimePicker2.Text = dataGridView2.SelectedRows[0].Cells[5].Value.ToString();
            comboBox2BLOOD.Text = dataGridView2.SelectedRows[0].Cells[6].Value.ToString();
        }
        private void clearText()
        {
            textId.Clear();
            textName.Clear();
            textPhone.Clear();
            
            comboCounty.SelectedIndex = -1;
            comboGender.SelectedIndex = -1;
            //  dateTimePicker2.Format = "";
            comboBox2BLOOD.SelectedIndex = -1;
            textId.Focus();
        }

        private void button3Print_Click_1(object sender, EventArgs e)
        {
            clearText();
        }

        private void button1refresh_Click_1(object sender, EventArgs e)
        {
            retrieve();
        }
    }
}
