﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace CLINIC_MAGEMENT_SOFTWARE
{
    public partial class REGISTRATION : Form
    {
        static string conString = "server=localhost;database=hospital;Uid=root;Password=;";
        MySqlConnection connection = new MySqlConnection(conString);
        MySqlCommand cmd;
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        MySqlDataReader dr;
        MySqlDataAdapter adapter;
        public REGISTRATION()
        {
            InitializeComponent();
          


        }
        private void generateID()
        {
            connection.Close();
            int a;
            string sql = "SELECT MAX(patient_Id) FROM patients";
            cmd = new MySqlCommand(sql, connection);

            try
            {
                connection.Open();
                dr = cmd.ExecuteReader();

                if (dr.Read())
                {
                    string val = dr[0].ToString();

                    if (val=="")
                    {
                        txtId.Text = "1";
                    }
                    else
                    {
                        a = Convert.ToInt32(dr[0].ToString());
                        a = a + 1;
                        txtId.Text = a.ToString();
                    }
                }
                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                connection.Close();
            }
        }
       private void btnSAVE_Click(object sender, EventArgs e)
        {
            if (txtId.Text == "cant be empty" || txtname.Text == "" || txtphone.Text == "" || txtage.Text == "" || cmbcounty.Text == "" || cmbgender.Text == ""||dateTimePicker1.Text==""||comboBoxblood.Text=="")
            {
                MessageBox.Show("ALL FIELD MUST BE FILLED!!!");
            }
            else
            {
                string sql = "SELECT * FROM patients WHERE patient_Id='" + txtId.Text + "'";
                cmd = new MySqlCommand(sql, connection);
                MySqlDataAdapter adapter = new MySqlDataAdapter(cmd);
                adapter.Fill(ds);
                int i = ds.Tables[0].Rows.Count;
                if (i > 0)
                {
                    MessageBox.Show("This patient ID already exist!!!", "ERROR MESSAGE", MessageBoxButtons.OKCancel, MessageBoxIcon.Error);
                    ds.Clear();

                }
                else
                {
                    try
                    {

                        connection.Open();
                        string query = "INSERT INTO  patients( patient_id, fullname, phone,county, gender,date_of_birth,blood_group) VALUES('" + txtId.Text + "' ,'" + txtname.Text + "','" + txtphone.Text + "','" + cmbcounty.Text + "','" + cmbgender.Text + "','"+dateTimePicker1.Text+"','"+comboBoxblood.Text+"')";
                        cmd = new MySqlCommand(query, connection);
                        cmd.ExecuteNonQuery();


                        adapter = new MySqlDataAdapter("SELECT * FROM patients ", connection);
                        adapter.Fill(dt);

                        MessageBox.Show("New Patient details has been  Successfully saved");

                        connection.Close();

                        printDocument1.Print();
                        cleartext();



                    }
                    
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }

                }
            }
        }
        private void retrieve2()
        {
            //MySqlDataAdapter adapter = new MySqlDataAdapter();
            //MySqlCommand cmd;

            //string sql = "SELECT * FROM patients";
            //cmd = new MySqlCommand(sql, connection);
            //adapter.SelectCommand = cmd;

            //adapter.Fill(dt);
            //dataGridView2.DataSource = dt;

            //MySqlCommand cmd = new MySqlCommand("SELECT * FROM patients;", connection);
            //try
            //{
            //    adapter = new MySqlDataAdapter(cmd);
            //    adapter.SelectCommand = cmd;
            //    dt = new DataTable();
            //    adapter.Fill(dt);
            //    BindingSource bs = new BindingSource();

            //    bs.DataSource = dt;
            //    dataGridView2.DataSource = bs;
            //    adapter.Update(dt);
            //}

            //catch (Exception ex)
            //{
            //    MessageBox.Show(ex.Message);

            //}

        }
        private void btnRetrieve_Click_1(object sender, EventArgs e)
        {
            
        }
        
        private void btnUpdate_Click_1(object sender, EventArgs e)
        {
          
        }
        

        private void btnDelete_Click_1(object sender, EventArgs e)
        {
           
        }

        private void textboxSearch_TextChanged_1(object sender, EventArgs e)
        {
            

        }

       private void clearText()
        {
            
        }


        private void dataGridView1_MouseClick_2(object sender, MouseEventArgs e)
        {
           //
            
        }
     private void count()
        {
            try
            {
                string query = "SELECT patient_Id FROM patients('patient_Id')";
                if (connection.State==ConnectionState.Closed)
                {
                    connection.Open();
                }
                MySqlCommand cmd = new MySqlCommand(query, connection);
                MySqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    int value = int.Parse(reader[0].ToString()) + 1;
                    //textId.Text = value.ToString();

                }
            }
            catch(Exception )
            {
                throw;
            }
            finally
            {
                if (connection.State== ConnectionState.Open)
                {
                    connection.Close();
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
           
        }
        private void clear()
        {

            textboxSearch.Clear();
            
        }
        private void btnSearch_Click(object sender, EventArgs e)
        {
            
            if (textboxSearch.Text == "")
            {
                MessageBox.Show("Enter the patient ID");

            }
            else
            {
                connection = new MySqlConnection(conString);
                connection.Open();
                adapter = new MySqlDataAdapter("SELECT * FROM patients WHERE patient_Id = '" + textboxSearch.Text + "' ", connection);
                dt = new DataTable();
                adapter.Fill(dt);
                dataGridView1.DataSource = dt;

                connection.Close();
                textboxSearch.Clear();
            }  
              
                //if (textboxSearch.Text == "")
                //{
                //    MessageBox.Show("Enter the patient ID");
                //}
                //else
                //{


                //    connection.Open();
                //    string selectQuery = "Select *  from patients WHERE patient_Id=" + int.Parse(textboxSearch.Text);
                //    cmd = new MySqlCommand(selectQuery, connection);
                //   // dt = new DataTable();
                //   // adapter.Fill(dt);
                //   // dataGridView1.DataSource = dt;
                //    dr = cmd.ExecuteReader();
                //    if (dr.Read())
                //    {

                //        MessageBox.Show("Patient Id is already registered");
                //   //string selected = dataGridView1.SelectedRows[0].Cells[5].Value.ToString();


                //    }
                //    else
                //    {
                //        MessageBox.Show("NO DETAILS FOUND");
                //        clearText();
                //    }
                //    connection.Close();
                //}

            
           
        }
        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            e.Graphics.DrawString("................. THIS CARD IS GIVEN FREE AT THE RECEPTION ............................................................",
             new Font("Arial", 12, FontStyle.Bold), Brushes.Blue, new Point(100, 150));


            e.Graphics.DrawString("Date:" + DateTime.Now.ToShortDateString(), new Font("Arial", 12, FontStyle.Bold), Brushes.Black, new Point(50, 200));

           // Bitmap bmp = new Bitmap(this.dataGridView2.Width, this.dataGridView2.Height);
          //  dataGridView2.DrawToBitmap(bmp, new System.Drawing.Rectangle(0, 0, this.dataGridView2.Width, this.dataGridView2.Height));
           // e.Graphics.DrawImage(bmp, 0, 0);

            e.Graphics.DrawString("PATIENT ID: " + txtId.Text.Trim(), new System.Drawing.Font("Arial", 12, FontStyle.Bold), Brushes.Black, new Point(100, 250));

            e.Graphics.DrawString("PATIENT NAME: " + txtname.Text.Trim(), new System.Drawing.Font("Arial", 12, FontStyle.Bold), Brushes.Black, new Point(100, 300));

            e.Graphics.DrawString("PATIENT AGE: " + txtage.Text.Trim(), new System.Drawing.Font("Arial", 12, FontStyle.Bold), Brushes.Black, new Point(100, 350));
            e.Graphics.DrawString("................................ALWAYS CARRY THIS CARD WITH YOU ..........................................................................",
              new Font("Arial", 12, FontStyle.Bold), Brushes.PaleVioletRed, new Point(50, 400));

        }

        private void btnEXit_Click(object sender, EventArgs e)
        {
         //   btnSAVE_Click( sender, e);
            printDocument1.Print();
        }

        private void cleartext()
        {
            txtId.Clear();

            txtname.Clear();
            txtphone.Clear();
            txtage.Clear();
            cmbcounty.SelectedIndex = -1;
                cmbgender.SelectedIndex = -1;
          //  dateTimePicker1.Text 
                comboBoxblood.SelectedIndex = -1;
        }

     

        private void txtphone_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;

            if (!char.IsDigit(ch) && ch != 8 && ch != 46)
            {
                e.Handled = true;
            }
        }

        private void txtage_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;

            if (!char.IsDigit(ch) && ch != 8 && ch != 46)
            {
                e.Handled = true;
            }

        }

        private void textPhone_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;

            if (!char.IsDigit(ch) && ch != 8 && ch != 46)
            {
                e.Handled = true;
            }
        }

        private void textAge_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;

            if (!char.IsDigit(ch) && ch != 8 && ch != 46)
            {
                e.Handled = true;
            }
        }

        private void printPreviewDialog1_Load(object sender, EventArgs e)
        {

        }

        private void textboxSearch_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;

            if (!char.IsDigit(ch) && ch != 8 && ch != 46)
            {
                e.Handled = true;
            }
        }

       
       

        private void button1_Click_1(object sender, EventArgs e)
        {
            generateID();
           
        }

        private void button2_Click(object sender, EventArgs e)
        {
            clear();
        }

        private void txtage_TextChanged(object sender, EventArgs e)
        {

            

        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            DateTime from = dateTimePicker1.Value;
            DateTime to = DateTime.Now;
            TimeSpan tspan = to - from;
            double days = tspan.TotalDays;
            txtage.Text = (days / 365).ToString("0");





        }

        private void txtId_TextChanged(object sender, EventArgs e)
        {

        }

        private void dateTimePicker1_CloseUp(object sender, EventArgs e)
        {
            //DateTime selectedDate = Convert.ToDateTime(dateTimePicker2.Value);
            //DateTime todayDate = Convert.ToDateTime(DateTime.Now);
            //if (selectedDate > todayDate)
            //{
            //    MessageBox.Show("Selected date Must be less than Today's date");
            //}

            DateTime fromdate = Convert.ToDateTime(dateTimePicker1.Text);
            DateTime todate1 = Convert.ToDateTime(dateTimePicker2.Text);
            if (fromdate <= todate1)
            {
                //TimeSpan daycount = todate1.Subtract(fromdate);
                //int dacount1 = Convert.ToInt32(daycount.Days) + 1;
                //MessageBox.Show(Convert.ToString(dacount1));
            }
            else
            {
                MessageBox.Show("Invalid  Date of birth ","ERROR MESSAGE");
            }
        }
    }
}
