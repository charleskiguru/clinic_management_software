﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace CLINIC_MAGEMENT_SOFTWARE
{
    
    public partial class PAYMENTS : Form
    {
        static string conString = "server=localhost;database=hospital;Uid=root;Password=;";
        MySqlConnection connection = new MySqlConnection(conString);
        MySqlCommand cmd;
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        MySqlDataReader dr;
        MySqlDataAdapter adapter;
        public PAYMENTS()
        {
            InitializeComponent();
            fill_combotest();


        }
        private void medicinetotalprice()
        {
            try
            {
                connection.Open();
                string Query = "SELECT  totalprice FROM pharmacy WHERE patient_Id='" + textBox1.Text + "' AND date='" + dateTimePicker1.Text + "'";
                cmd = new MySqlCommand(Query, connection);
                dr = cmd.ExecuteReader();

                while (dr.Read())
                {

                    string stotalprice = dr.GetString("totalprice");
                    textBox3.Text = stotalprice;


                }
                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }
        }

        private void fill_combotest()
        {
            try
            {
                connection.Open();
                string Query = "SELECT  Test FROM test";
                cmd = new MySqlCommand(Query, connection);
                dr = cmd.ExecuteReader();

                while (dr.Read())
                {

                    string stest = dr.GetString("Test");
                    comboBox1.Items.Add(stest);


                }

                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }
        }
        private void PAYMENTS_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            
        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                connection.Open();
                string query = "SELECT Test,Amount FROM test WHERE Test='" + comboBox1.Text + "'";
                cmd = new MySqlCommand(query, connection);
                dr = cmd.ExecuteReader();

                while (dr.Read())
                {

                    string mTest = dr.GetString("Test");
                    string mAmount = dr.GetString("Amount");
                    comboBox1.Text = mTest;
                    textBox2.Text = mAmount;


                }
                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private List<models.CartItems> shoppingCart = new List<models.CartItems>();

        private void button3_Click(object sender, EventArgs e)
        {
            
        }
        private bool IsValidated()
        {
            if (textBox1.Text.Trim() == string.Empty)
            {
                MessageBox.Show("patient ID is required", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                textBox2.Focus();
                return false;
            }
            if (comboBox1.Text.Trim() == string.Empty)
            {
                MessageBox.Show("test  name is required", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                textBox2.Focus();
                return false;
            }


            bool Found = false;
            if (CartdataGridView.Rows.Count > 0)
            {
                foreach (DataGridViewRow row in CartdataGridView.Rows)
                {
                    if (Convert.ToString(row.Cells[0].Value) == comboBox1.Text)
                    {
                        MessageBox.Show("The product selected already exit in the cart!!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return false;
                    }
                }
            }
            return true;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            try
            {
                connection.Open();
                string Query = "SELECT patient_Id, test FROM patient_info WHERE patient_Id='" + textBox1.Text + "'AND date='" + dateTimePicker1.Text + "'";
                cmd = new MySqlCommand(Query, connection);
                dr = cmd.ExecuteReader();



                while (dr.Read())
                {
                    string stest = dr.GetString("test");
                    textBox5.Text = stest;

                    // Namelist.Items.Add(smedicine);

                }
                connection.Close();
                medicinetotalprice();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }
            connection.Close();
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            if (IsValidated())
            {
                models.CartItems item = new models.CartItems()
                {
                    // patient_Id = Convert.ToInt16(textBox2.Text.Trim()),
                    labtest = comboBox1.Text,
                    labcharges = Convert.ToInt16(textBox2.Text.Trim()),

                };
                shoppingCart.Add(item);


                CartdataGridView.DataSource = null;
                CartdataGridView.DataSource = shoppingCart;

                decimal totalAmount = shoppingCart.Sum(x => x.labcharges);
                textBox6.Text = totalAmount.ToString();

                //decimal lab_charge = Convert.ToInt16(textBox7.Text.Trim());
                //decimal CONSULTATION_CHARGE = Convert.ToInt16(textBox3.Text.Trim());

                decimal TotaltoPay = totalAmount;
                textBox6.Text = TotaltoPay.ToString();

                comboBox1.SelectedIndex = -1;
                textBox2.Clear();


                // shoppingCart.Clear();
            }
        }
    }
}
