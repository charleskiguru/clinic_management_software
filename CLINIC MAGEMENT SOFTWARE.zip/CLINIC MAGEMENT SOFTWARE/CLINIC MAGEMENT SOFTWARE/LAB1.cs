﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace CLINIC_MAGEMENT_SOFTWARE
{
    public partial class LAB1 : Form
    {
        static string conString = "server=localhost;database=hospital;Uid=root;Password=;";
        MySqlConnection connection = new MySqlConnection(conString);
        MySqlCommand cmd;
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        MySqlDataReader dr;
        MySqlDataAdapter adapter;
        public LAB1()
        {
            InitializeComponent();
        }

        private void button1SUBMIT_Click(object sender, EventArgs e)
        {
            if (textBoxID.Text == "" || textBoxTEST.Text == "")
            {
                MessageBox.Show("All field must be filled before saving");
            }
            else
            {

                connection.Open();
                string query = "INSERT INTO  lab(patient_Id,test,datee) VALUES('" + textBoxID.Text + "','" + textBoxTEST.Text + "','"+dateTimePicker1.Text+"' )";
                cmd = new MySqlCommand(query, connection);
                cmd.ExecuteNonQuery();


                adapter = new MySqlDataAdapter("SELECT * FROM lab ", connection);
                adapter.Fill(dt);

                MessageBox.Show("Patient lab  detail's has been  successfully saved");

                connection.Close();


            }
        }
    }
}
