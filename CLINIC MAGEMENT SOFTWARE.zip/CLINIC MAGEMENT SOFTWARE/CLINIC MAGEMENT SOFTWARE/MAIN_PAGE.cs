﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;


namespace CLINIC_MAGEMENT_SOFTWARE
{
    
    public partial class MAIN_PAGE : Form
    {
        static string conString = "server=localhost;database=hospital;Uid=root;Password=;";
        MySqlConnection connection = new MySqlConnection(conString);
     //   MySqlCommand cmd;
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
      //  MySqlDataReader dr;
      //  MySqlDataAdapter adapter;
        public MAIN_PAGE(string usertype)
        {

            InitializeComponent();
            labelusertype.Text = usertype;
            //if (labelusertype.Text == "ADMIN")
            //{
            //    dOCTORToolStripMenuItem.Visible = false;
            //    mEDICINEToolStripMenuItem.Visible = false;
            //    bACKUPToolStripMenuItem.Visible = false;
            //    mANAGEPATIENTSToolStripMenuItem.Visible = false;
            //    dOCTORToolStripMenuItem.Visible = false;
            //    pHARMACYToolStripMenuItem.Visible = false;
            //    rEPORTToolStripMenuItem.Visible = false;
            //    rECEPTIONToolStripMenuItem.Visible = false;


            //}
            //else if (labelusertype.Text == "RECEPTIONIST")
            if(labelusertype.Text == "RECEPTIONIST")
            {
                cONSULTATIONToolStripMenuItem.Visible = false;
                mEDICINEToolStripMenuItem.Visible = false;
                lABToolStripMenuItem.Visible = false;
                bACKUPToolStripMenuItem.Visible = false;
                rEPORTToolStripMenuItem.Visible = false;
                dOCTORToolStripMenuItem.Visible = false;
                pHARMACYToolStripMenuItem.Visible = false;
                rEPORTToolStripMenuItem.Visible = false;

            }
        }

        private void bTNGEGISTER_Click(object sender, EventArgs e)
        {
            
           // this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
           
            
        }

        private void button3_Click(object sender, EventArgs e)
        {
           
          //this.Hide();  
                
         }

        private void button2_Click(object sender, EventArgs e)
        {
            ADD_doctor obj = new ADD_doctor();
            obj.Show();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Form1 obj = new Form1();
            obj.Show();
            this.Hide();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            //CRYSTALREPORTS obj = new CRYSTALREPORTS();
           
            //this.Hide();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            LAB obj = new LAB();
            obj.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            PHARMACY obj = new PHARMACY();
            obj.Show();
        }
        //display todays date and time .
        private void MAIN_PAGE_Load(object sender, EventArgs e)
        {
           DateTime datetime = DateTime.Now;
           this.label1.Text = datetime.ToString();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            CRYSTALREPORTS obj = new CRYSTALREPORTS();
            obj.Show();
        }

        private void dOCTORToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ADD_doctor obj = new ADD_doctor();
            obj.Show();
        }

        private void cONSULTATIONToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CONSULTATION OBJ = new CONSULTATION();
            OBJ.Show();
        }

        private void mEDICINEToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ADD_MEDICINE obj = new ADD_MEDICINE();
            obj.Show();
        }

        private void lABToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LAB obj = new LAB();
            obj.Show();
        }

        private void rEPORTToolStripMenuItem_Click(object sender, EventArgs e)
        {
            REPORTS obj = new REPORTS();
            obj.Show();
        }

        private void rECEPTIONToolStripMenuItem_Click(object sender, EventArgs e)
        {
            REGISTRATION obj = new REGISTRATION();
            obj.Show();
        }

        private void mANAGEPATIENTSToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MANAGE_PATIENTS mg = new MANAGE_PATIENTS();
            mg.Show();
        }

        private void backup()
        {
            using (MySqlConnection con = new MySqlConnection(conString))
            {
                using (MySqlCommand command = new MySqlCommand())
                {
                    using (MySqlBackup mb = new MySqlBackup(command))
                    {
                        try
                        {
                            command.Connection = con;
                            con.Open();
                            mb.ExportToFile("C:\\backup\\backup.sql");
                            MessageBox.Show("backup successfull....!!!", "Success Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            con.Close();
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show(ex.Message);
                        }
                    }
                }
            }
        }

        private void bACKUPToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }

        private void restore()
        {
           
            using (MySqlConnection conn = new MySqlConnection(conString))
            {
                using (MySqlCommand command = new MySqlCommand())
                {
                    using (MySqlBackup mb = new MySqlBackup(command))
                    {
                        try
                        {
                            command.Connection = conn;
                            conn.Open();
                            mb.ImportFromFile("C:\\backup\\backup.sql");
                            MessageBox.Show("Restore successfull....!!!", "Success Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            conn.Close();
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show(ex.Message);
                        }
                    }
                }
            }
        }

        private void rESTOREDATAToolStripMenuItem_Click(object sender, EventArgs e)
        {
            restore();
        }

        private void rESTOREToolStripMenuItem_Click(object sender, EventArgs e)
        {
            backup();
        }

        private void pHARMACYToolStripMenuItem_Click(object sender, EventArgs e)
        {
            PHARMACY pham = new PHARMACY();
            pham.Show();

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void pAYMENTSToolStripMenuItem_Click(object sender, EventArgs e)
        {
            PAYMENTS OBJ = new PAYMENTS();
            OBJ.Show();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            
        }

        private void cASHIERToolStripMenuItem_Click(object sender, EventArgs e)
        {
            PAYMENTS PAY = new PAYMENTS();
            PAY.Show();
        }
    }
}
