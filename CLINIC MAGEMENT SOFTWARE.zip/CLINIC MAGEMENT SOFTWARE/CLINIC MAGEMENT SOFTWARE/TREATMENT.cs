﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace CLINIC_MAGEMENT_SOFTWARE
{
    public partial class TREATMENT : Form
    {
        static string conString = "server=localhost;database=hospital;Uid=root;Password=;";
        MySqlConnection connection = new MySqlConnection(conString);
        MySqlCommand cmd;
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        MySqlDataReader dr;
        MySqlDataAdapter adapter;
        public TREATMENT()
        {
            InitializeComponent();
            fillpatientIDt();

        }
        private void retrievetreat()
        {

            MySqlCommand cmd = new MySqlCommand("SELECT * FROM treatment;", connection);
            try
            {
                adapter = new MySqlDataAdapter(cmd);
                adapter.SelectCommand = cmd;
                dt = new DataTable();
                adapter.Fill(dt);
                BindingSource bs = new BindingSource();

                bs.DataSource = dt;
                dataGridView1.DataSource = bs;
                adapter.Update(dt);
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }

        }
        private void button1save_Click(object sender, EventArgs e)
        {
            if (cmbPid.Text == "" || dateTimePicker3.Text == "" || txtDisease.Text == "" || txtmedicine.Text == "")
            {
                MessageBox.Show("ENTER All  ", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
            else
            {
                connection.Open();
                string query = "INSERT INTO treatment(patient_Id, date,disease,medicine ) VALUES('" + cmbPid.Text + "' ,'" + dateTimePicker3.Text + "','" + txtDisease.Text + "','" + txtmedicine.Text + "')";
                cmd = new MySqlCommand(query, connection);
                cmd.ExecuteNonQuery();


                adapter = new MySqlDataAdapter("SELECT * FROM treatment ", connection);
                adapter.Fill(dt);

                MessageBox.Show("Patient treatment details has been  Successfully saved");
                connection.Close();
                retrievetreat();
            }
        }

        private void button3update_Click(object sender, EventArgs e)
        {
            if (cmbPid.Text == "" || dateTimePicker3.Text == "" || txtDisease.Text == "" || txtmedicine.Text == "" )
            {
                MessageBox.Show("The row to updated should be selected ", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
            else
            {
                string selected = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
                int patient_Id = Convert.ToInt32(selected);

                update3(patient_Id, dateTimePicker3.Text, txtDisease.Text, txtmedicine.Text);
            }
        }
        private void update3(int patient_Id, string date, string disease, string medicine)
        {
            string sql = "UPDATE lab SET date='" + date + " ',disease= '" + disease + "',medicine'" + medicine + "' WHERE patient_Id=" + patient_Id + "";
            cmd = new MySqlCommand(sql, connection);

            try
            {
                connection.Open();
                adapter = new MySqlDataAdapter(cmd);
                adapter.UpdateCommand = connection.CreateCommand();
                adapter.UpdateCommand.CommandText = sql;

                if (MessageBox.Show("Do you want to update this patients treatment details??", "confirmation message", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    if (adapter.UpdateCommand.ExecuteNonQuery() > 0)
                    {
                        MessageBox.Show("Succesfully Updated");
                       


                    }
                }

                else
                {

                }
                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                connection.Close();
            }
        }
        private void button2delete_Click(object sender, EventArgs e)
        {

            if (cmbPid.Text == "" || dateTimePicker3.Text == "" || txtDisease.Text == "" || txtmedicine.Text == "" )
            {
                MessageBox.Show("Select a row to be DELETED", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
            else
            {
                string selected = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
                int patient_Id = Convert.ToInt32(selected);
                delete3(patient_Id);

            }
        }
        private void delete3(int patient_Id)
        {
            string sql = "DELETE FROM treatment WHERE date=" + patient_Id + "";
            try
            {
                connection.Open();
                cmd = new MySqlCommand(sql, connection);
                adapter = new MySqlDataAdapter(cmd);
                adapter.DeleteCommand = connection.CreateCommand();
                adapter.DeleteCommand.CommandText = sql;

                if (MessageBox.Show("Want to delete this patients  treatment  details from database??", "confirmation messsage", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) == DialogResult.OK)
                {
                    if (adapter.DeleteCommand.ExecuteNonQuery() > 0)
                    {
                        MessageBox.Show("Seccesfully deleted");
                        retrievetreat();
                       

                    }
                }
                else
                {
                    
                }
                connection.Close();


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                connection.Close();

            }
        }

        private void fillpatientIDt()
        {
            try
            {
                connection.Open();
                string Query = "SELECT patient_Id  FROM patient_info ";
                cmd = new MySqlCommand(Query, connection);
                dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    string slab = dr.GetString("patient_ID");
                    cmbPid.Items.Add(slab);

                }
                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }


        }
       
//seach by button
        private void search()
        {
            connection.Open();
            string selectQuery = "Select *  from treatment WHERE patient_Id=" + int.Parse(cmbPid.Text);
            cmd = new MySqlCommand(selectQuery, connection);

            dr = cmd.ExecuteReader();
            if (dr.Read())
            {


                string selected = dataGridView1.SelectedRows[0].Cells[4].Value.ToString();

            }
            else
            {
                MessageBox.Show("NO DETAILS FOUND");

            }
            connection.Close();
        }

        private void dataGridView1_MouseClick(object sender, MouseEventArgs e)
        {

            cmbPid.Text = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
            dateTimePicker3.Text = dataGridView1.SelectedRows[0].Cells[1].Value.ToString();
            txtDisease.Text = dataGridView1.SelectedRows[0].Cells[2].Value.ToString();
            txtmedicine.Text = dataGridView1.SelectedRows[0].Cells[3].Value.ToString();
            
        }

        private void cmbPid_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
