﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CLINIC_MAGEMENT_SOFTWARE.models
{
    class CartItem
    {
       // public int patient_Id { get; set; }
        public string medicine_name { get; set; }
        public string medicine_type { get; set; }

      public decimal price { get; set; }
       // public decimal unit_price{ get; set; }
      //  public decimal total_price { get; set; }


        //  public decimal lab_charge { get; set; }

    }
}
