﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CLINIC_MAGEMENT_SOFTWARE.models
{
    class CartItems
    {
        public string labtest { get; set; }
        public decimal labcharges { get; set; }
    }
}
