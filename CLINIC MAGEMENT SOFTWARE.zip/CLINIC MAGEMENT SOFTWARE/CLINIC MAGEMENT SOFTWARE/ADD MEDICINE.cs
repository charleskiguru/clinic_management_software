﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace CLINIC_MAGEMENT_SOFTWARE
{
    public partial class ADD_MEDICINE : Form
    {
        static string conString = "server=localhost;database=hospital;Uid=root;Password=;";
        MySqlConnection connection = new MySqlConnection(conString);
        MySqlCommand cmd;
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        MySqlDataReader dr;
        MySqlDataAdapter adapter;
        public ADD_MEDICINE()
        {
            InitializeComponent();
            retrieveMed();
        }
        private void retrieveMed()
        {

            MySqlCommand cmd = new MySqlCommand("SELECT * FROM medicine;", connection);
            try
            {
                adapter = new MySqlDataAdapter(cmd);
                adapter.SelectCommand = cmd;
                dt = new DataTable();
                adapter.Fill(dt);
                BindingSource bs = new BindingSource();

                bs.DataSource = dt;
                dataGridView1.DataSource = bs;
                adapter.Update(dt);
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }

        }
        private void button1_Click(object sender, EventArgs e)
        {
            if (txtmed.Text == "" || cmbtype.Text == "")
            {
                MessageBox.Show("All field must be filled before saving");
            }

            else
            {
                try
                {
                    string sql = "SELECT * FROM medicine WHERE medicine_id='" + textBox1.Text + "'";
                    cmd = new MySqlCommand(sql, connection);
                    MySqlDataAdapter adapter = new MySqlDataAdapter(cmd);
                    adapter.Fill(ds);
                    int i = ds.Tables[0].Rows.Count;
                    if (i > 0)
                    {
                        MessageBox.Show("This medicine name already exist!!!", "ERROR MESSAGE", MessageBoxButtons.OKCancel, MessageBoxIcon.Error);
                        ds.Clear();

                    }

                    else
                    {

                        connection.Open();
                        string query = "INSERT INTO  medicine(medicine_name, medicine_type,price) VALUES('" + txtmed.Text + "','" + cmbtype.Text + "','"+txtboxprice.Text+"')";
                        cmd = new MySqlCommand(query, connection);
                        cmd.ExecuteNonQuery();


                        adapter = new MySqlDataAdapter("SELECT * FROM medicine ", connection);
                        adapter.Fill(dt);

                        MessageBox.Show("medicine details has been  successfully saved");

                        connection.Close();
                        clear();
                        retrieveMed();

                    }

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }
        private void update1(int medicine_id, string medicine_name, string medicine_type,string price)
        {
            string sql = "UPDATE medicine SET medicine_name='" + medicine_name + " ',medicine_type= '" + medicine_type + "',price='"+price+"' WHERE medicine_id=" + medicine_id + "";
            cmd = new MySqlCommand(sql, connection);

            try
            {
                connection.Open();
                adapter = new MySqlDataAdapter(cmd);
                adapter.UpdateCommand = connection.CreateCommand();
                adapter.UpdateCommand.CommandText = sql;

                if (MessageBox.Show("Do you want to update this medicine details??", "confirmation message", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    if (adapter.UpdateCommand.ExecuteNonQuery() > 0)
                    {
                        MessageBox.Show("Succesfully Updated");
                        retrieveMed();
                        
                        clear();

                    }
                }

                else
                {
                    clearText();
                }
                connection.Close();
                // retrieve();


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                connection.Close();
            }
        }
        private void button3Update_Click(object sender, EventArgs e)
        {
            if (textBox1.Text==""||txtmed.Text == "" || cmbtype.Text == "" )
            {
                MessageBox.Show("The row to updated should be selected ", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
            else
            {
                string selected = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
                int medicine_id = Convert.ToInt32(selected);

                update1(medicine_id, txtmed.Text, cmbtype.Text,txtboxprice.Text);
            }
        }
        private void clearText()
        {
            textBox1.Clear();
            txtmed.Clear();
            cmbtype.SelectedIndex = -1;
            txtmed.Focus();


        }
        private void dataGridView1_MouseClick(object sender, MouseEventArgs e)
        {
            textBox1.Text = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
            txtmed.Text = dataGridView1.SelectedRows[0].Cells[1].Value.ToString();
            cmbtype.Text = dataGridView1.SelectedRows[0].Cells[2].Value.ToString();
            txtboxprice.Text = dataGridView1.SelectedRows[0].Cells[3].Value.ToString();

        }
        private void delete(int medicine_id)
        {
            string sql = "DELETE FROM medicine WHERE medicine_id=" + medicine_id + "";
            try
            {
                connection.Open();
                cmd = new MySqlCommand(sql, connection);
                adapter = new MySqlDataAdapter(cmd);
                adapter.DeleteCommand = connection.CreateCommand();
                adapter.DeleteCommand.CommandText = sql;

                if (MessageBox.Show("Want to delete this patients details from database??", "confirmation messsage", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) == DialogResult.OK)
                {
                    if (adapter.DeleteCommand.ExecuteNonQuery() > 0)
                    {
                        MessageBox.Show("Seccesfully deleted");
                        retrieveMed();

                    }
                }
                else
                {
                    clearText();
                }
                connection.Close();


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                connection.Close();

            }
        }
        private void button2delete_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "" || txtmed.Text == "" || cmbtype.Text == "")
            {
                MessageBox.Show("Select a row to be DELETED", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
            else
            {
                string selected = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
                int patient_Id = Convert.ToInt32(selected);
                delete(patient_Id);
               // retrieve2();
            }
        }
        private void clear()
        {
            textBox1.Clear();
            txtmed.Clear();
            cmbtype.SelectedIndex = -1;
            txtboxprice.Clear();


        }
        private void button2_Click(object sender, EventArgs e)
        {
            clear();
        }
    }
}