﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace CLINIC_MAGEMENT_SOFTWARE
{
    public partial class PHARMACY : Form
    {
        static string conString = "server=localhost;database=hospital;Uid=root;Password=;";
        MySqlConnection connection = new MySqlConnection(conString);
        MySqlCommand cmd;
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        MySqlDataReader dr;
        MySqlDataAdapter adapter;
        public PHARMACY()
        {
            InitializeComponent();
            fill_comboId();
            fill_combomed();

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }
        private void filllabcharges()
        {
            try
            {
                connection.Open();
                string Query = "SELECT  lab_charges FROM lab where patient_Id='"+textBox2.Text+"' AND date='"+dateTimePicker1.Text+"'";
                cmd = new MySqlCommand(Query, connection);
                dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    
                        string smedicine = dr.GetString("lab_charges");
                        textBox7.Text = smedicine;
                   

                }
                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }
        }
      
        private void fill_comboId()
        {
            //try
            //{
            //    connection.Open();
            //    string Query = "SELECT  patient_Id FROM patient_info";
            //    cmd = new MySqlCommand(Query, connection);
            //    dr = cmd.ExecuteReader();

            //    while (dr.Read())
            //    {
            //        string spatient_Id = dr.GetString("patient_Id");
            //        textBox2.Items.Add(spatient_Id);

            //    }
            //    connection.Close();
            //}
            //catch (Exception ex)
            //{
            //    MessageBox.Show(ex.Message);

            //}
        }

        private void fill_combomed()
        {
            try
            {
                connection.Open();
                string Query = "SELECT  medicine_name FROM medicine";
                cmd = new MySqlCommand(Query, connection);
                dr = cmd.ExecuteReader();

                while (dr.Read())
                {

                    string smedicine = dr.GetString("medicine_name");
                    comboBox2.Items.Add(smedicine);


                }
               
                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }
        }

        private void PHARMACY_Load(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            try
            {
                connection.Open();
                string Query = "SELECT patient_Id, medicine FROM patient_info WHERE patient_Id='" + textBox2.Text + "'AND date='" + dateTimePicker1.Text + "'";
                cmd = new MySqlCommand(Query, connection);
                dr = cmd.ExecuteReader();



                while (dr.Read())
                {
                    string smedicine = dr.GetString("medicine");
                    textBox1.Text = smedicine;

                    // Namelist.Items.Add(smedicine);

                }
                connection.Close();
               
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }
            connection.Close();
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                connection.Open();
                string query = "SELECT medicine_name,medicine_type,price FROM medicine WHERE medicine_name='" + comboBox2.Text + "'";
                cmd = new MySqlCommand(query, connection);
                dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                 
                    string medicine_name = dr.GetString("medicine_name");
                    string medicine_type = dr.GetString("medicine_type");
                    string sprice = dr.GetString("price");
                    comboBox2.Text = medicine_name;
                     textBox8.Text = medicine_type;
                    textBox5.Text = sprice;

                

                }
                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //if (this.comboBox2.Text != "")
            //{
            //    Namelist.Items.Add(this.comboBox2.Text);
            //    this.comboBox2.Focus();
            //    this.comboBox2.SelectedIndex = -1;
            //}
            //else
            //{
            //    MessageBox.Show("enter medicine to add to the medicine box", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            //    this.comboBox2.Focus();
            //}

        }

        private void button2_Click(object sender, EventArgs e)
        {
            // sales();
            savet();
          printDocument1.Print();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            //if (this.Namelist.SelectedIndex >= 0)
            //{
            //    this.Namelist.Items.RemoveAt(this.Namelist.SelectedIndex);

            //}
        }
        private List<models.CartItem> shoppingCart = new List<models.CartItem>();
        private void button5_Click(object sender, EventArgs e)
        {
             if (IsValidated())
            {
                models.CartItem item = new models.CartItem()
                {
                   // patient_Id = Convert.ToInt16(textBox2.Text.Trim()),
                    medicine_name = comboBox2.Text,

                    medicine_type = textBox8.Text,
                  price= Convert.ToInt16(textBox5.Text.Trim()),

                

                };
                shoppingCart.Add(item);


                CartdataGridView.DataSource = null;
                CartdataGridView.DataSource = shoppingCart;

                decimal totalAmount = shoppingCart.Sum(x => x.price);
                textBox4.Text = totalAmount.ToString();

                decimal lab_charge = Convert.ToInt16(textBox7.Text.Trim());
                decimal CONSULTATION_CHARGE= Convert.ToInt16(textBox3.Text.Trim());

                decimal TotaltoPay = totalAmount + lab_charge + CONSULTATION_CHARGE;
                textBox6.Text = TotaltoPay.ToString();

                comboBox2.SelectedIndex = -1;
                textBox8.Clear();
                textBox5.Clear();

                // shoppingCart.Clear();
            }
        }

        private bool IsValidated()
        {
            if (textBox2.Text.Trim() == string.Empty)
            {
                MessageBox.Show("patient ID is required", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                textBox2.Focus();
                return false;
            }
            if (comboBox2.Text.Trim() == string.Empty)
            {
                MessageBox.Show("medicine name is required", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                textBox2.Focus();
                return false;
            }


            bool Found = false;
            if (CartdataGridView.Rows.Count > 0)
            {
                foreach (DataGridViewRow row in CartdataGridView.Rows)
                {
                    if (Convert.ToString(row.Cells[0].Value) == comboBox2.Text)
                    {
                        MessageBox.Show("The product selected already exit in the cart!!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return false;
                    }
                }
            }
            return true;
        }

        private void CartdataGridView_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == System.Windows.Forms.MouseButtons.Right)
            {
                var hti = CartdataGridView.HitTest(e.X, e.Y);
                CartdataGridView.Rows[hti.RowIndex].Selected = true;

                contextMenuStrip1.Show(CartdataGridView, e.X, e.X);
            }
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int index = CartdataGridView.CurrentCell.RowIndex;
            shoppingCart.RemoveAt(index);

            CartdataGridView.DataSource = null;
            CartdataGridView.DataSource = shoppingCart;

            decimal totalAmount = shoppingCart.Sum(x => x.price);
            textBox4.Text = totalAmount.ToString();


        }

        private void button1_Click_1(object sender, EventArgs e)
        {
           // textBox6.Text = Convert.ToInt32(textBox3.Text) + Convert.ToInt32(textBox4.Text).ToString();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            e.Graphics.DrawString("Date:" + DateTime.Now.ToShortDateString(), new Font("Arial", 12, FontStyle.Bold), Brushes.Black, new Point(35, 190));


            e.Graphics.DrawString("PATIENT ID:   " +textBox2.Text.Trim(), new Font("Arial", 12, FontStyle.Bold), Brushes.Black, new Point(35, 220));
            e.Graphics.DrawString(".......................................................................................................................................................................................",
           new Font("Arial", 12, FontStyle.Bold), Brushes.Black, new Point(25, 230));


            //e.Graphics.DrawString("CONSULTATION CHARGES:   " + textBox3.Text.Trim(), new Font("Arial", 12, FontStyle.Bold), Brushes.Black, new Point(35, 300));
            //e.Graphics.DrawString(".......................................................................................................................................................................................",
            //new Font("Arial", 12, FontStyle.Bold), Brushes.Black, new Point(30, 300));


            e.Graphics.DrawString("MEDICINE NAME ", new Font("Arial", 12, FontStyle.Bold), Brushes.Black, new Point(35, 255));
            e.Graphics.DrawString("MEDICINE TYPE ", new Font("Arial", 12, FontStyle.Bold), Brushes.Black, new Point(250, 255));
            e.Graphics.DrawString("PRICE ", new Font("Arial", 12, FontStyle.Bold), Brushes.Black, new Point(410, 255));
           // e.Graphics.DrawString("Total Price ", new Font("Arial", 12, FontStyle.Bold), Brushes.Black, new Point(660, 255));

            e.Graphics.DrawString(".......................................................................................................................................................................................",
               new Font("Arial", 12, FontStyle.Bold), Brushes.Black, new Point(30, 270));

            int yPos = 295;

            foreach (var i in shoppingCart)
            {

                e.Graphics.DrawString(i.medicine_name, new Font("Arial", 12, FontStyle.Bold), Brushes.Black, new Point(35, yPos));
                e.Graphics.DrawString(i.medicine_type.ToString(), new Font("Arial", 12, FontStyle.Bold), Brushes.Black, new Point(250, yPos));
              e.Graphics.DrawString(i.price .ToString(), new Font("Arial", 12, FontStyle.Bold), Brushes.Black, new Point(410, yPos));
               // e.Graphics.DrawString(i.total_price.ToString(), new Font("Arial", 12, FontStyle.Bold), Brushes.Black, new Point(400, yPos));


                yPos += 30;
            }
            
            e.Graphics.DrawString(".......................................................................................................................................................................................",
               new Font("Arial", 12, FontStyle.Bold), Brushes.Black, new Point(25, yPos));

            e.Graphics.DrawString("Total Amount  :      Ksh." +textBox4 .Text.Trim(), new Font("Arial", 12, FontStyle.Bold), Brushes.Black, new Point(560, yPos + 40));
          //  e.Graphics.DrawString("LABORATORY CHARGES:  Ksh.                           " + textBox7.Text.Trim(), new Font("Arial", 12, FontStyle.Bold), Brushes.Black, new Point(15, yPos + 20));
          //  e.Graphics.DrawString(".......................................................................................................................................................................................",
                    //       new Font("Arial", 12, FontStyle.Bold), Brushes.Black, new Point(25, yPos+25));
         //   e.Graphics.DrawString("CONSULTATION CHARGES:Ksh.                    " + textBox3.Text.Trim(), new Font("Arial", 12, FontStyle.Bold), Brushes.Black, new Point(35, yPos + 40));



        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }
        private void savet()
        {
            if (textBox2.Text == "" || textBox4.Text == "")
            {
                MessageBox.Show("ALL MUST BE FILLED!!!");
            }
            //else
            //{
            //    string sql = "SELECT * FROM test WHERE patient_Id='" + textBox2.Text + "'";
            //    cmd = new MySqlCommand(sql, connection);
            //    MySqlDataAdapter adapter = new MySqlDataAdapter(cmd);
            //    adapter.Fill(ds);
            //    int i = ds.Tables[0].Rows.Count;
            //    if (i > 0)
            //    {
            //        MessageBox.Show("This test name already exist!!!", "ERROR MESSAGE", MessageBoxButtons.OKCancel, MessageBoxIcon.Error);
            //        ds.Clear();

            //    }
                else
                {
                   // try
                   // {

                        connection.Open();
                        string query = "INSERT INTO  pharmacy( patient_Id,date, totalprice) VALUES('" + textBox2.Text + "','"+dateTimePicker1.Text+"','" + textBox4.Text + "')";
                        cmd = new MySqlCommand(query, connection);
                        cmd.ExecuteNonQuery();


                        adapter = new MySqlDataAdapter("SELECT * FROM pharmacy ", connection);
                        adapter.Fill(dt);

                        MessageBox.Show(" successfully saved");

                        connection.Close();
                       

                    }

                    //catch (Exception ex)
                    //{
                    //    MessageBox.Show(ex.Message);
                    //}

                }
          //  }
       // }
        private void sales()
        {


            for (int i = 0; i < CartdataGridView.Rows.Count; i++)
            {
                cmd = new MySqlCommand(@"INSERT INTO pharmacy (patient_Id,date, totalprice) VALUES('" + textBox2.Text+ "','"+dateTimePicker1.Text+"','" + CartdataGridView.Rows[i].Cells[0].Value.ToString() + "','" + CartdataGridView.Rows[i].Cells[1].Value.ToString() + "','" + CartdataGridView.Rows[i].Cells[2].Value.ToString() + "','"+textBox4.Text+"')", connection);
                connection.Open();
                cmd.ExecuteNonQuery();

                connection.Close();
            }
        }
        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;

            if (!char.IsDigit(ch) && ch != 8 && ch != 46)
            {
                e.Handled = true;
            }
        }

        private void textBox5_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;

            if (!char.IsDigit(ch) && ch != 8 && ch != 46)
            {
                e.Handled = true;
            }
        }

        private void button1_Click_2(object sender, EventArgs e)
        {
            
        }
    }
}