﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace CLINIC_MAGEMENT_SOFTWARE
{
    public partial class CONSULTATION : Form
    {
        static string conString = "server=localhost;database=hospital;Uid=root;Password=;";
        MySqlConnection connection = new MySqlConnection(conString);
        MySqlCommand cmd;
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
 
        MySqlDataReader dr;
        MySqlDataAdapter adapter;
    
        public CONSULTATION()
        {
            InitializeComponent();
            retrieve2();
            fill_comboID();
            fill_comboDpt();
            fill_comboDoc();
        }
        private void enable()
        {
            txtBp.Enabled = true;
            cmbDocID.Enabled = true;
            dateTimePicker1.Enabled = true;
            cmbDept.Enabled = true;
            txtComp.Enabled = true;
            textBoxT.Enabled = true;


        }
        private void disable()
        {
            txtBp.Enabled = false;
            cmbDocID.Enabled = false;
            dateTimePicker1.Enabled = false;
            cmbDept.Enabled = false;
            txtComp.Enabled = false;
            textBoxT.Enabled = false;


        }
        private void retrieve2()
        {

            MySqlCommand cmd = new MySqlCommand("SELECT patient_Id, date, department, doctor_ID, bloodpressure, complaints, disease, medicine FROM patient_info   ", connection);
            try
            {
                adapter = new MySqlDataAdapter(cmd);
                adapter.SelectCommand = cmd;
                dt = new DataTable();
                adapter.Fill(dt);
                BindingSource bs = new BindingSource();

                bs.DataSource = dt;
                dataGridView1.DataSource = bs;
                adapter.Update(dt);
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }

        }
        private void buttonsave_Click(object sender, EventArgs e)
        {

            if (txtID.Text == "" || dateTimePicker1.Text == "" || cmbDept.Text == "" || cmbDocID.Text == "" || txtBp.Text == "" || txtComp.Text == "")
            {
                MessageBox.Show("All field must be entered before saving");
            }
            else
            {
                string sql = "SELECT * FROM patient_info WHERE patient_Id='" + txtID.Text + "' AND date='" + dateTimePicker1.Text + "'";
                cmd = new MySqlCommand(sql, connection);
                MySqlDataAdapter adapter = new MySqlDataAdapter(cmd);
                adapter.Fill(ds);
                int i = ds.Tables[0].Rows.Count;
                if (i > 0)
                {
                    MessageBox.Show("This patient details exist in todays date!!!", "ERROR MESSAGE", MessageBoxButtons.OKCancel, MessageBoxIcon.Error);
                    ds.Clear();

                }

                else
                {

                    connection.Open();
                    string query = "INSERT INTO  patient_info(patient_Id, date, department, doctor_ID,  bloodpressure, complaints, disease, medicine,test,lab_result) VALUES('" + txtID.Text + "' ,'" + dateTimePicker1.Text + "','" + cmbDept.Text + "','" + cmbDocID.Text + "','" + txtBp.Text + "','" + txtComp.Text + "','" + textBoxD.Text + "','" + textBoxM.Text + "','" + textBoxT.Text + "','" + txtlabresult.Text + "')";
                    cmd = new MySqlCommand(query, connection);
                    cmd.ExecuteNonQuery();


                    adapter = new MySqlDataAdapter("SELECT * FROM patient_info ", connection);
                    adapter.Fill(dt);

                    MessageBox.Show("Patient details has been  Successfully saved");

                    savelab();
                    cleartext();
                    retrieve2();
                    connection.Close();
                }


            }

            }
       
        private void buttonUpdate_Click(object sender, EventArgs e)
        {
            if (txtID.Text==""||dateTimePicker1.Text==""|| cmbDept.Text == "" || cmbDocID.Text == "" || txtBp.Text == "" || txtComp.Text == ""|| textBoxD.Text==""||textBoxM.Text=="")
            {
                MessageBox.Show("The row to updated should be selected ", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
            else
            {
                string selected = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
                int patient_Id = Convert.ToInt32(selected);

                update(patient_Id,dateTimePicker1.Text,cmbDept.Text, cmbDocID.Text, txtBp.Text, txtComp.Text,textBoxD.Text,textBoxM.Text,textBoxT.Text,txtlabresult.Text);
            }
        }
        private void update(int patient_Id, string date, string department, string doctor_ID, string bloodpressure, string complaints,string  disease,string medicine,string test,string lab_result)
        {
            string sql = "UPDATE patient_info SET  date='"+date+"', department= '" + department + "',doctor_ID='" + doctor_ID + "',bloodpressure='" + bloodpressure + "',complaints='" + complaints + "',disease='"+disease+"',medicine='"+medicine+"',test='"+test+ "',lab_result='"+ lab_result + "' WHERE patient_Id=" + patient_Id+" AND date='"+dateTimePicker1.Text+"' ";
            cmd = new MySqlCommand(sql, connection);

            try
            {
                connection.Open();
                adapter = new MySqlDataAdapter(cmd);
                adapter.UpdateCommand = connection.CreateCommand();
                adapter.UpdateCommand.CommandText = sql;

                if (MessageBox.Show("Do you want to update this patient details??", "confirmation message", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    if (adapter.UpdateCommand.ExecuteNonQuery() > 0)
                    {
                        MessageBox.Show("Succesfully Updated");
                        cleartext();

                    }
                }

                else
                {
                    cleartext();
                }
                connection.Close();
                retrieve2();


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                connection.Close();
            }
        }
        private void buttonDelete_Click(object sender, EventArgs e)
        {
            if (txtID.Text == "" || dateTimePicker1.Text == "" || cmbDept.Text == "" || cmbDocID.Text == "" || txtBp.Text == "" || txtComp.Text == "" )
            {
                MessageBox.Show("Select a row to be DELETED", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
            else
            {
                string selected = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
                int patient_Id = Convert.ToInt32(selected);
              
                delete(patient_Id);

            }
        }
        private void delete(int patient_Id)
        {
            string sql = "DELETE  FROM patient_info WHERE patient_Id=" + patient_Id+"  AND date='"+dateTimePicker1.Text+"'";
            try
            {
                connection.Open();
                cmd = new MySqlCommand(sql, connection);
                adapter = new MySqlDataAdapter(cmd);
                adapter.DeleteCommand = connection.CreateCommand();
                adapter.DeleteCommand.CommandText = sql;

                if (MessageBox.Show("Want to delete this patient's details from database??", "confirmation messsage", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) == DialogResult.OK)
                {
                    if (adapter.DeleteCommand.ExecuteNonQuery() > 0)
                    {
                        MessageBox.Show("seccesfully deleted");
                        cleartext();

                    }
                }
                else
                {
                    cleartext();
                }
                connection.Close();
                retrieve2();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                connection.Close();

            }
        }
        private void cleartext()
        {
            txtID.Clear();
            cmbDept.SelectedIndex = -1;
            cmbDocID.SelectedIndex = -1;
            txtBp.Clear();
            txtComp.Clear();
           
            textBoxD.Clear();
            textBoxM.Clear();
            textBoxT.Clear();
            txtlabresult.Clear();
           
           

        }
        private void fill_comboID()
        {
            //try
            //{
            //    connection.Open();
            //    string Query = "SELECT patient_Id  FROM patients ";
            //    cmd = new MySqlCommand(Query, connection);
            //    dr = cmd.ExecuteReader();

            //    while (dr.Read())
            //    {
            //        string spatient_Id = dr.GetString("patient_Id");
            //        //cmbID.Items.Add(spatient_Id);
            //      txtID.Items.Add(spatient_Id);

            //    }
            //    connection.Close();
            //}
            //catch (Exception ex)
            //{
            //    MessageBox.Show(ex.Message);

            //}
        }

        private void fill_comboDpt()
        {
            try
            {
                connection.Open();
                string Query = "SELECT  departments FROM department ORDER BY depart_id ";
                cmd = new MySqlCommand(Query, connection);
                dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    string sdepart = dr.GetString("departments");
                    cmbDept.Items.Add(sdepart);

                }
                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }
        }
        //fill combo for doctor_Id
        private void fill_comboDoc()
        {
            try
            {
                connection.Open();
                string Query = "SELECT doctor_ID FROM doctor ORDER BY doctor_ID";
                cmd = new MySqlCommand(Query, connection);
                dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    string sdepart = dr.GetString("doctor_ID");
                    cmbDocID.Items.Add(sdepart);
                    
                    

                }
                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }


        }

        private void buttonSearch_Click(object sender, EventArgs e)
        {
            connection = new MySqlConnection(conString);
            connection.Open();
            adapter = new MySqlDataAdapter("SELECT patient_Id,date,department, doctor_ID, bloodpressure, complaints,disease, medicine  FROM patient_info WHERE date ='"+dateTimePicker1.Text+ "' AND patient_Id='"+ txtID .Text+ "' ", connection);
           
            dt = new DataTable();
       
           adapter.Fill(dt);
            dataGridView1.DataSource = dt;
            disable();
            connection.Close();

           
           // cleartext();

            // connection.Open();
            // string sql = "SELECT patient_Id, date, department, doctor_ID,complaints FROM patient_info ";
            //MySqlCommand cmd = new MySqlCommand(sql, connection);
            // MySqlDataReader reader = cmd.ExecuteReader();

            // listView1.Items.Clear();

            // while (reader.Read())
            // {
            //     ListViewItem iv = new ListViewItem(reader.GetInt32(0).ToString(),reader.GetString(1));
            //     iv.SubItems.Add(reader.GetString(1));
            //     iv.SubItems.Add(reader.GetString(2));
            //     //iv.SubItems.Add(reader.GetString(3));
            //     //iv.SubItems.Add(reader.GetString(4));
            //     //iv.SubItems.Add(reader.GetString(5));
            //     //iv.SubItems.Add(reader.GetString(6));
            //     //iv.SubItems.Add(reader.GetString(7));
            //     //iv.SubItems.Add(reader.GetString(8));
            //     //iv.SubItems.Add(reader.GetString(9));
            //     //iv.SubItems.Add(reader.GetString(10));
            //     listView1.Items.Add(iv);
            // }
            // reader.Close();
            // cmd.Dispose();
            // connection.Close();


        }

        private void dataGridView1_MouseClick(object sender, MouseEventArgs e)
        {


            txtID.Text = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
            dateTimePicker1.Text = dataGridView1.SelectedRows[0].Cells[1].Value.ToString();
            cmbDept.Text = dataGridView1.SelectedRows[0].Cells[2].Value.ToString();
            cmbDocID.Text = dataGridView1.SelectedRows[0].Cells[3].Value.ToString();
            txtBp.Text = dataGridView1.SelectedRows[0].Cells[4].Value.ToString();
            txtComp.Text = dataGridView1.SelectedRows[0].Cells[5].Value.ToString();
          //  textBoxT.Text = dataGridView1.SelectedRows[0].Cells[6].Value.ToString();
            textBoxD.Text = dataGridView1.SelectedRows[0].Cells[6].Value.ToString();
            textBoxM.Text = dataGridView1.SelectedRows[0].Cells[7].Value.ToString();





        }

        private void button1REFRESH_Click(object sender, EventArgs e)
        {
            retrieve2();
            enable();
            cleartext();
        }
        private void retrievelab()
        {

            MySqlCommand cmd = new MySqlCommand("SELECT patient_Id,test,results FROM lab", connection);
            try
            {
                adapter = new MySqlDataAdapter(cmd);
                adapter.SelectCommand = cmd;
                dt = new DataTable();
                adapter.Fill(dt);
                BindingSource bs = new BindingSource();

                bs.DataSource = dt;
             //   dataGridView2.DataSource = bs;
                adapter.Update(dt);
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }

        }
        private void buttonlAB_Click(object sender, EventArgs e)
        {
            LAB1 OBJ = new LAB1();
            OBJ.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            retrievelab();
        }

        private void button1treatment_Click(object sender, EventArgs e)
        {
            TREATMENT obj = new TREATMENT();
            obj.Show();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            //TREATMENT obj = new TREATMENT();
            //obj.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            //LAB1 lab = new LAB1();
           // lab.Show();
        
        }

        private void button2SEND_Click(object sender, EventArgs e)
        {
           
        }
    private void savelab()
        {
            if (txtID.Text == "" || textBoxT.Text == "")
            {
                // MessageBox.Show("All field must be filled before saving");
            }
            else
            {

                //connection.Open();
                string query = "INSERT INTO  lab(patient_Id,test,date) VALUES('" + txtID.Text + "','" + textBoxT.Text + "','" + dateTimePicker1.Text + "' )";
                cmd = new MySqlCommand(query, connection);
                cmd.ExecuteNonQuery();


                adapter = new MySqlDataAdapter("SELECT * FROM lab ", connection);
                adapter.Fill(dt);

                // MessageBox.Show("Patient lab  details has been  successfully saved");

                // connection.Close();


            }
        }
        private void button2_Click_1(object sender, EventArgs e)
        {
            
        }

        private void CONSULTATION_Load(object sender, EventArgs e)
        {
           
        }

        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
        
           

        //    fm.textBox9.Text = this.dataGridView1.CurrentRow.Cells[8].Value.ToString();
       

            //fm.ShowDialog();


        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (txtID.Text == "")
            {
                MessageBox.Show("Enter the patient ID");
            }
            else
            {
                connection = new MySqlConnection(conString);
                connection.Open();
                adapter = new MySqlDataAdapter("SELECT patient_Id,test,lab_result FROM lab WHERE patient_Id = '" + txtID.Text + "' AND date='"+dateTimePicker1.Text+"' ", connection);
                dt = new DataTable();
                adapter.Fill(dt);
                dataGridView2.DataSource = dt;
                connection.Close();
                //this.dataGridView2.Rows.Clear();
                
            }

        }

        private void button5_Click(object sender, EventArgs e)
        {
            connection = new MySqlConnection(conString);
            connection.Open();
            adapter = new MySqlDataAdapter("SELECT * FROM patient_info WHERE patient_Id='"+txtID.Text+"'", connection);

            dt = new DataTable();

            adapter.Fill(dt);
            dataGridView1.DataSource = dt;

            connection.Close();
            button4_Click(sender, e);
        }

        private void txtID_TextChanged(object sender, EventArgs e)
        {
            string sql = "SELECT * FROM patients WHERE patient_Id='" + txtID.Text + "'";
            cmd = new MySqlCommand(sql, connection);
            MySqlDataAdapter adapter = new MySqlDataAdapter(cmd);
            adapter.Fill(ds);
            int i = ds.Tables[0].Rows.Count;
            if (i >0)
            {
                // MessageBox.Show("This patient ID already exist!!!", "ERROR MESSAGE", MessageBoxButtons.OKCancel, MessageBoxIcon.Error);
             ds.Clear();


            }
            else
            {
                MessageBox.Show("THIS ID IS NOT REGISTERED", "ERROR MESSAGE");
                // MessageBox.Show("This patient ID is not registered!!!", "ERROR MESSAGE", MessageBoxButtons.OKCancel, MessageBoxIcon.Error);
                txtID.Clear();

            }
        }

        private void txtID_KeyPress(object sender, KeyPressEventArgs e)
        {
            
        }

        private void dataGridView2_MouseClick(object sender, MouseEventArgs e)
        {

            textBoxT.Text = dataGridView2.SelectedRows[0].Cells[1].Value.ToString();
            txtlabresult.Text = dataGridView2.SelectedRows[0].Cells[2].Value.ToString();
        }

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            e.Graphics.DrawString("............................TREATMENT CARD ................................................",
            new Font("Arial", 12, FontStyle.Bold), Brushes.Blue, new Point(100, 150));

         
           // e.Graphics.DrawString("Date:" + DateTime.Now.ToShortDateString(), new Font("Arial", 12, FontStyle.Bold), Brushes.Black, new Point(100, 200));

            // Bitmap bmp = new Bitmap(this.dataGridView2.Width, this.dataGridView2.Height);
            //  dataGridView2.DrawToBitmap(bmp, new System.Drawing.Rectangle(0, 0, this.dataGridView2.Width, this.dataGridView2.Height));
            // e.Graphics.DrawImage(bmp, 0, 0);

            e.Graphics.DrawString("PATIENT ID: " + txtID.Text.Trim(), new System.Drawing.Font("Arial", 12, FontStyle.Bold), Brushes.Black, new Point(100, 250));

           e.Graphics.DrawString("DATE: " + dateTimePicker1.Text, new System.Drawing.Font("Arial", 12, FontStyle.Bold), Brushes.Black, new Point(100, 300));
         
            e.Graphics.DrawString("DOCTOR ID: " + cmbDocID.Text.Trim(), new System.Drawing.Font("Arial", 12, FontStyle.Bold), Brushes.Black, new Point(100, 350));
            e.Graphics.DrawString("DEPARTMENT: " + cmbDept.Text.Trim(), new System.Drawing.Font("Arial", 12, FontStyle.Bold), Brushes.Black, new Point(100, 400));
            e.Graphics.DrawString("BLOOD PRESSURE: " + txtBp.Text.Trim(), new System.Drawing.Font("Arial", 12, FontStyle.Bold), Brushes.Black, new Point(100, 450));
            e.Graphics.DrawString("COMPLAINTS: " + txtComp.Text.Trim(), new System.Drawing.Font("Arial", 12, FontStyle.Bold), Brushes.Black, new Point(100, 500));
            e.Graphics.DrawString("DISEASE: " + textBoxD.Text.Trim(), new System.Drawing.Font("Arial", 12, FontStyle.Bold), Brushes.Black, new Point(100, 550));
            e.Graphics.DrawString("MEDICINE: " + textBoxM.Text.Trim(), new System.Drawing.Font("Arial", 12, FontStyle.Bold), Brushes.Black, new Point(100, 600));




            e.Graphics.DrawString("................................WISH YOU QUICK RECOVERY  ............................................................",
             new Font("Arial", 12, FontStyle.Bold), Brushes.PaleVioletRed, new Point(150, 650));
        }

        private void button6_Click(object sender, EventArgs e)
        {
            printDocument1.Print();
        }

        private void cmbDocID_SelectedIndexChanged(object sender, EventArgs e)
        {
        }
    }
}
