﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.IO;

namespace CLINIC_MAGEMENT_SOFTWARE
{
    public partial class Form1 : Form
    {
        static string conString = "server=localhost;database=hospital;Uid=root;Pwd=;";
        MySqlConnection con = new MySqlConnection(conString);
        MySqlCommand cmd;
        MySqlDataAdapter adapter;
        MySqlDataReader dr;
        public Form1()
        {
            InitializeComponent();
        }
      
        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void BTNLogin_Click(object sender, EventArgs e)
        {
            if (IsValidated())
            {
                string sql = "SELECT usertype,username,password FROM user WHERE usertype='" + logincomboBox.Text + "' AND  username='" + this.textboxUser.Text + "' AND password='" + this.textBoxPass.Text + "'";
                cmd = new MySqlCommand(sql, con);
                try
                {
                    con.Open();

                    adapter = new MySqlDataAdapter(cmd);
                    dr = cmd.ExecuteReader();
                    int count = 0;

                    while (dr.Read())
                    {
                        count = count + 1;

                    }

                    if (count > 0)
                    {
                        string usertype = logincomboBox.Text;
                        if (logincomboBox.Text == "ADMIN")
                        {
                      
                            MAIN_PAGE obj = new MAIN_PAGE(usertype);
                            obj.Show();
                            this.Hide();
                        }
                       // else if (logincomboBox.Text == "RECEPTIONIST")
                       else
                        {
                         
                            MAIN_PAGE obj = new MAIN_PAGE(usertype);
                            obj.Show();
                            this.Hide();

                        }

                        //else
                        //{
                           
                        //    MAIN_PAGE obj = new MAIN_PAGE(usertype);
                        //    obj.Show();
                        //    this.Hide();

                        //}
                    }
                    else
                    {
                        MessageBox.Show("Details didnt match correctly!!");
                    }
                    con.Close();

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                    con.Close();
                }

            }
        }

        private bool IsValidated()
        {
         if (logincomboBox.SelectedIndex == -1)
            {
                MessageBox.Show("Please select Usertype.", "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            if (textboxUser.Text.Trim() == string.Empty)
            {
                MessageBox.Show("Enter username.", "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            if (textBoxPass.Text.Trim() == string.Empty)
            {
                MessageBox.Show("Enter password.", "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            return true;
    }

        private void BtnEXIT_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            //progressBar1.Value = progressBar1.Value + 2;
            //if (progressBar1.Value>99)
            //{
            //    Form1 f = new Form1();
            //    f.Show();
            //    this.Hide();
            //    timer1.Enabled = true;
            //}

        }
      }
    }
    

