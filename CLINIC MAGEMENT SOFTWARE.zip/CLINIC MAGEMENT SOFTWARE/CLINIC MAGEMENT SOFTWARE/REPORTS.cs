﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace CLINIC_MAGEMENT_SOFTWARE
{
    public partial class REPORTS : Form
    {
        static string conString = "server=localhost;database=hospital;Uid=root;Password=;";
        MySqlConnection connection = new MySqlConnection(conString);
        MySqlCommand cmd;
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        DataTable dt1= new DataTable();
        MySqlDataReader dr;
        MySqlDataAdapter adapter;
        
        public REPORTS()
        {
            InitializeComponent();
        
     PATIENTHISTORY();
        // retrieve();
        }
        private void populate(String patient_Id, string fullname,  string date,string doctor_ID,string complaints,string test, string lab_result,string  disease,string medicine)
        {
            dataGridView2.Rows.Add(patient_Id,fullname,date,doctor_ID,complaints,test,lab_result, disease, medicine);

        }
        private void retrieve()
        {
            dataGridView2.Rows.Clear();
            //SQL STMT
        // String sql = "SELECT patient_info.patient_Id, patients.fullname,patient_info.date,patient_info.doctor_ID,patient_info.complaints,lab.test,lab.lab_result,patient_info.disease,patient_info.medicine  FROM patients INNER JOIN patient_info ON patients.patient_Id=patient_info.patient_Id INNER JOIN lab ON patients.patient_Id=lab.patient_Id ";
            String sql = "SELECT patient_info.patient_Id, patients.fullname,patient_info.date,patient_info.doctor_ID,patient_info.complaints,patient_info.test,patient_info.lab_result,patient_info.disease,patient_info.medicine  FROM patients INNER JOIN patient_info ON patients.patient_Id=patient_info.patient_Id  ";


            cmd = new MySqlCommand(sql, connection);
            try
            {
                connection.Open();
                adapter = new MySqlDataAdapter(cmd);
                adapter.Fill(dt);

                foreach (DataRow row in dt.Rows)
                {
                    populate(row[0].ToString(), row[1].ToString(), row[2].ToString(), row[3].ToString(), row[4].ToString(), row[5].ToString(), row[6].ToString(), row[7].ToString(), row[8].ToString());

                }
                connection.Close();
                dt.Rows.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void PATIENTHISTORY()
        {
            MySqlCommand cmd =new MySqlCommand("SELECT patient_info.patient_Id, patients.fullname,patient_info.date,patient_info.doctor_ID,patient_info.complaints,patient_info.test,patient_info.lab_result,patient_info.disease,patient_info.medicine  FROM patients INNER JOIN patient_info ON patients.patient_Id=patient_info.patient_Id   ",connection);

          //  MySqlCommand cmd = new MySqlCommand("SELECT patient_info.patient_Id, patients.fullname,patient_info.doctor_ID,patients.blood_group,patient_info.complaints,patient_info.date,lab.test,lab.lab_result ,patient_info.disease, patient_info.medicine FROM patients INNER JOIN patient_info ON patients.patient_Id=patient_info.patient_Id INNER JOIN lab ON lab.patient_Id ", connection);
            try
            {
                adapter = new MySqlDataAdapter(cmd);

                adapter.SelectCommand = cmd;
                dt = new DataTable();
                adapter.Fill(dt);
                BindingSource bs = new BindingSource();

                bs.DataSource = dt;
                dataGridView2.DataSource = bs;
                adapter.Update(dt);
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }


        }
        private void button2FILTER_Click(object sender, EventArgs e)
        {
           
        }

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            e.Graphics.DrawString("................. ............................PATIENT REPORTS ................................................",
             new Font("Arial", 12, FontStyle.Bold), Brushes.Blue, new Point(10, 200));


            e.Graphics.DrawString("Date:" + DateTime.Now.ToShortDateString(), new Font("Arial", 12, FontStyle.Bold), Brushes.Black, new Point(10,250));

            Bitmap bmp = new Bitmap(this.dataGridView2.Width, this.dataGridView2.Height);
             dataGridView2.DrawToBitmap(bmp, new System.Drawing.Rectangle(0, 0, this.dataGridView2.Width, this.dataGridView2.Height));
            e.Graphics.DrawImage(bmp, 10, 300);

           // e.Graphics.DrawString("................................ALWAYS CARRY THIS CARD WITH YOU ..........................................................................",
            //  new Font("Arial", 12, FontStyle.Bold), Brushes.PaleVioletRed, new Point(50, 400));

        }

        private void button1_Click(object sender, EventArgs e)
        {
            printDocument1.Print();
        }

        private void textBox1SEARCH_TextChanged(object sender, EventArgs e)
        {
            //DataView DV = new DataView(dt);
            //DV.RowFilter = string.Format("patient_Id  LIKE '%{0}'", textBox1SEARCH.Text.ToString());

            //dataGridView1.DataSource = DV;

           

        }

        private void button2_Click(object sender, EventArgs e)
        {
           
        }

        private void button3_Click(object sender, EventArgs e)
        {
            PATIENTHISTORY();
        }

        private void button2FILTER_Click_1(object sender, EventArgs e)
        {
            connection.Open();
            adapter = new MySqlDataAdapter("SELECT patient_info.patient_Id, patients.fullname,patient_info.date,patient_info.doctor_ID,patient_info.complaints,patient_info.test,patient_info.lab_result,patient_info.disease,patient_info.medicine FROM patients INNER JOIN patient_info ON patients.patient_Id=patient_info.patient_Id  WHERE date between '" + dateTimePicker1.Text.ToString() + "' AND '" + dateTimePicker2.Text.ToString() + "'", connection);
            DataSet ds = new DataSet();
            adapter.Fill(ds, "patients,patient_info");
           dataGridView2.DataSource = ds.Tables["patients,patient_info"];
            connection.Close();
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            if (textBoxsearch.Text == "")
            {
                MessageBox.Show("Enter the patient ID");

            }
            else
            {
                connection = new MySqlConnection(conString);
                connection.Open();
                

                adapter = new MySqlDataAdapter("SELECT patient_info.patient_Id, patients.fullname,patient_info.date,patient_info.doctor_ID,patient_info.complaints,patient_info.test,patient_info.lab_result,patient_info.disease,patient_info.medicine  FROM patients INNER JOIN patient_info ON patients.patient_Id=patient_info.patient_Id WHERE patient_Id='"+textBoxsearch.Text+"'  ", connection);
                dt = new DataTable();
                adapter.Fill(dt);
                dataGridView2.DataSource = dt;

                connection.Close();
                textBoxsearch.Clear();
            }
        }

        private void textBoxsearch_TextChanged(object sender, EventArgs e)
        {
            DataView DV = new DataView(dt);
           DV.RowFilter = string.Format("patient_Id like'%{0}'", textBoxsearch.Text.ToString());
         

            dataGridView2.DataSource = DV;

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            printDocument1.Print();
        }

        private void textBoxsearch_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;

            if (!char.IsDigit(ch) && ch != 8 && ch != 46)
            {
                e.Handled = true;
            }
        }
    }
}
