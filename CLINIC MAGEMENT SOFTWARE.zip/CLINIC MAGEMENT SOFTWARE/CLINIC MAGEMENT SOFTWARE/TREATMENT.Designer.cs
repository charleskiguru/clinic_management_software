﻿namespace CLINIC_MAGEMENT_SOFTWARE
{
    partial class TREATMENT
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel6 = new System.Windows.Forms.Panel();
            this.txtDisease = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.dateTimePicker3 = new System.Windows.Forms.DateTimePicker();
            this.label17 = new System.Windows.Forms.Label();
            this.cmbPid = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.txtmedicine = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.button3update = new System.Windows.Forms.Button();
            this.button2delete = new System.Windows.Forms.Button();
            this.button1save = new System.Windows.Forms.Button();
            this.panel6.SuspendLayout();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel6
            // 
            this.panel6.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel6.Controls.Add(this.txtDisease);
            this.panel6.Controls.Add(this.label18);
            this.panel6.Controls.Add(this.dateTimePicker3);
            this.panel6.Controls.Add(this.label17);
            this.panel6.Controls.Add(this.cmbPid);
            this.panel6.Controls.Add(this.label6);
            this.panel6.Location = new System.Drawing.Point(1, 0);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(615, 128);
            this.panel6.TabIndex = 3;
            // 
            // txtDisease
            // 
            this.txtDisease.Location = new System.Drawing.Point(128, 75);
            this.txtDisease.Multiline = true;
            this.txtDisease.Name = "txtDisease";
            this.txtDisease.Size = new System.Drawing.Size(217, 29);
            this.txtDisease.TabIndex = 6;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(2, 78);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(120, 13);
            this.label18.TabIndex = 4;
            this.label18.Text = "DISEASE DIAGNOSED";
            // 
            // dateTimePicker3
            // 
            this.dateTimePicker3.Location = new System.Drawing.Point(336, 20);
            this.dateTimePicker3.Name = "dateTimePicker3";
            this.dateTimePicker3.Size = new System.Drawing.Size(200, 20);
            this.dateTimePicker3.TabIndex = 3;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(294, 22);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(36, 13);
            this.label17.TabIndex = 2;
            this.label17.Text = "DATE";
            // 
            // cmbPid
            // 
            this.cmbPid.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbPid.FormattingEnabled = true;
            this.cmbPid.Location = new System.Drawing.Point(113, 19);
            this.cmbPid.Name = "cmbPid";
            this.cmbPid.Size = new System.Drawing.Size(156, 21);
            this.cmbPid.TabIndex = 1;
            this.cmbPid.SelectedIndexChanged += new System.EventHandler(this.cmbPid_SelectedIndexChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(3, 19);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(67, 13);
            this.label6.TabIndex = 0;
            this.label6.Text = "PATIENT ID";
            // 
            // panel5
            // 
            this.panel5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel5.Controls.Add(this.txtmedicine);
            this.panel5.Controls.Add(this.label20);
            this.panel5.Location = new System.Drawing.Point(1, 134);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(356, 117);
            this.panel5.TabIndex = 4;
            // 
            // txtmedicine
            // 
            this.txtmedicine.Location = new System.Drawing.Point(101, 35);
            this.txtmedicine.Multiline = true;
            this.txtmedicine.Name = "txtmedicine";
            this.txtmedicine.Size = new System.Drawing.Size(229, 64);
            this.txtmedicine.TabIndex = 12;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(2, 54);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(62, 13);
            this.label20.TabIndex = 8;
            this.label20.Text = "MEDICINE ";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(1, 257);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(623, 172);
            this.dataGridView1.TabIndex = 5;
            this.dataGridView1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.dataGridView1_MouseClick);
            // 
            // button3update
            // 
            this.button3update.BackColor = System.Drawing.Color.Yellow;
            this.button3update.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button3update.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3update.ForeColor = System.Drawing.Color.Black;
            this.button3update.Location = new System.Drawing.Point(512, 141);
            this.button3update.Name = "button3update";
            this.button3update.Size = new System.Drawing.Size(76, 33);
            this.button3update.TabIndex = 10;
            this.button3update.Text = "UPDATE";
            this.button3update.UseVisualStyleBackColor = false;
            this.button3update.Click += new System.EventHandler(this.button3update_Click);
            // 
            // button2delete
            // 
            this.button2delete.BackColor = System.Drawing.Color.Yellow;
            this.button2delete.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button2delete.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2delete.ForeColor = System.Drawing.Color.Black;
            this.button2delete.Image = global::CLINIC_MAGEMENT_SOFTWARE.Properties.Resources.delete_300x300;
            this.button2delete.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button2delete.Location = new System.Drawing.Point(438, 215);
            this.button2delete.Name = "button2delete";
            this.button2delete.Size = new System.Drawing.Size(101, 36);
            this.button2delete.TabIndex = 9;
            this.button2delete.Text = "DELETE";
            this.button2delete.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button2delete.UseVisualStyleBackColor = false;
            this.button2delete.Click += new System.EventHandler(this.button2delete_Click);
            // 
            // button1save
            // 
            this.button1save.BackColor = System.Drawing.Color.Yellow;
            this.button1save.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button1save.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1save.ForeColor = System.Drawing.Color.Black;
            this.button1save.Image = global::CLINIC_MAGEMENT_SOFTWARE.Properties.Resources.Register;
            this.button1save.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button1save.Location = new System.Drawing.Point(390, 141);
            this.button1save.Name = "button1save";
            this.button1save.Size = new System.Drawing.Size(101, 36);
            this.button1save.TabIndex = 8;
            this.button1save.Text = "SAVE";
            this.button1save.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button1save.UseVisualStyleBackColor = false;
            this.button1save.Click += new System.EventHandler(this.button1save_Click);
            // 
            // TREATMENT
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(626, 434);
            this.Controls.Add(this.button3update);
            this.Controls.Add(this.button2delete);
            this.Controls.Add(this.button1save);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel6);
            this.Name = "TREATMENT";
            this.Text = "TREATMENT";
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.TextBox txtDisease;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.DateTimePicker dateTimePicker3;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.ComboBox cmbPid;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button button3update;
        private System.Windows.Forms.Button button2delete;
        private System.Windows.Forms.Button button1save;
        private System.Windows.Forms.TextBox txtmedicine;
    }
}