﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace CLINIC_MAGEMENT_SOFTWARE
{
    public partial class ADD_doctor : Form
    {
        static string conString = "server=localhost;database=hospital;Uid=root;Password=;";
        MySqlConnection connection = new MySqlConnection(conString);
        MySqlCommand cmd;
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
       MySqlDataReader dr;
        MySqlDataAdapter adapter;
        public ADD_doctor()
        {
            InitializeComponent();
            retrieve2();
            generateID();
            fill_combo();
            department();
        }
        private void department()
        {

            MySqlCommand cmd = new MySqlCommand("SELECT * FROM department;", connection);
            try
            {
                adapter = new MySqlDataAdapter(cmd);
                adapter.SelectCommand = cmd;
                dt = new DataTable();
                adapter.Fill(dt);
                BindingSource bs = new BindingSource();

                bs.DataSource = dt;
                dataGridView4.DataSource = bs;
                adapter.Update(dt);
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }

        }
        private void generateID()
        {
            connection.Close();
            int a;
            string sql = "SELECT MAX(doctor_ID) FROM doctor";
            cmd = new MySqlCommand(sql, connection);

            try
            {
                connection.Open();
                dr = cmd.ExecuteReader();

                if (dr.Read())
                {
                    string val = dr[0].ToString();

                    if (val == "")
                    {
                        textID.Text = "1";
                    }
                    else
                    {
                        a = Convert.ToInt32(dr[0].ToString());
                        a = a + 1;
                        textID.Text = a.ToString();

                    }
                }
                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                connection.Close();
            }
        }
        private void retrieve2()
        {

            MySqlCommand cmd = new MySqlCommand("SELECT * FROM doctor;", connection);
            try
            {
                adapter = new MySqlDataAdapter(cmd);
                adapter.SelectCommand = cmd;
                dt = new DataTable();
                adapter.Fill(dt);
                BindingSource bs = new BindingSource();

                bs.DataSource = dt;
                dataGridView1.DataSource = bs;
                adapter.Update(dt);
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }

        }
        private void fill_combo()
        {
            try
            {
                connection.Open();
                string Query = "SELECT * FROM department ORDER BY departments ";
                cmd = new MySqlCommand(Query, connection);
                dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    string sdepartment = dr.GetString("departments");
                    cmbDepartment.Items.Add(sdepartment);

                }
                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }
        }
       
        private void dataGridView1_MouseClick_1(object sender, MouseEventArgs e)
        {

        }

        private void buttonretrieve_Click_1(object sender, EventArgs e)
        {

        }

        private void buttonsave_Click_1(object sender, EventArgs e)
        {

        }

        private void buttonUpdate_Click_1(object sender, EventArgs e)
        {

        }

        private void buttonDelete_Click_1(object sender, EventArgs e)
        {

        }

        private void buttonsave_Click(object sender, EventArgs e)
        {
            if (textID.Text == "" || textname.Text == "" || textphone.Text == "" || cmbDepartment.Text == "" || comboGender.Text == "")
            {
                MessageBox.Show("ALL FIELD MUST BE FILLED!!!");
            }
            else
            {
                //    string sql = "SELECT * FROM doctor WHERE doctor_ID='" + textID.Text + "'";
                //    cmd = new MySqlCommand(sql, connection);
                //    MySqlDataAdapter adapter = new MySqlDataAdapter(cmd);
                //    adapter.Fill(ds);
                //    int i = ds.Tables[0].Rows.Count;
                //    if (i > 0)
                //    {
                //        MessageBox.Show("This Doctor ID already exist!!!", "ERROR MESSAGE", MessageBoxButtons.OKCancel, MessageBoxIcon.Error);
                //        ds.Clear();

                //    }
                //    else
                //{
                //    try
                //    {

                connection.Open();
                string query = "INSERT INTO  doctor( doctor_ID, doctor_name, gender, phone, department) VALUES('" + textID.Text + "' ,'" + textname.Text + "','" + comboGender.Text + "','" + textphone.Text + "','" + cmbDepartment.Text + "')";
                cmd = new MySqlCommand(query, connection);
                cmd.ExecuteNonQuery();


                adapter = new MySqlDataAdapter("SELECT * FROM doctor ", connection);
                adapter.Fill(dt);

                MessageBox.Show("New Doctor details has been  Successfully saved");
                clearText();
                connection.Close();



                //    }

                //    catch (Exception ex)
                //    {
                //        MessageBox.Show(ex.Message);
                //    }

                //    }
                //}
            }
        }
        private void update1(int doctor_ID, string doctor_name, string gender, string phone, string department)
        {
            string sql = "UPDATE doctor SET doctor_name='" + doctor_name + " ',gender= '" + gender + "',phone='" + phone + "',department='" + department + "' WHERE doctor_ID=" + doctor_ID + "";
            cmd = new MySqlCommand(sql, connection);

            try
            {
                connection.Open();
                adapter = new MySqlDataAdapter(cmd);
                adapter.UpdateCommand = connection.CreateCommand();
                adapter.UpdateCommand.CommandText = sql;

                if (MessageBox.Show("Do you want to update this doctors' details??", "confirmation message", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    if (adapter.UpdateCommand.ExecuteNonQuery() > 0)
                    {
                        MessageBox.Show("Succesfully Updated");
                        retrieve2();
                        clearText();
                    }
                }

                else
                {
                    clearText();
                }
                connection.Close();

                retrieve2();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                connection.Close();
            }
        }

        private void buttonUpdate_Click(object sender, EventArgs e)
        {
            if (textname.Text == "" || comboGender.Text == "" || textphone.Text == "" || cmbDepartment.Text == "")
            {
                MessageBox.Show("The row to updated should be selected ", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Error);



            }
            else
            {
                string selected = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
                int doctor_ID = Convert.ToInt32(selected);

                update1(doctor_ID, textname.Text, comboGender.Text, textphone.Text, cmbDepartment.Text);
            }
        }
        private void delete1(int doctor_ID)
        {
            string sqla = "DELETE FROM doctor WHERE doctor_ID=" + doctor_ID + "";
            try
            {
                connection.Open();
                cmd = new MySqlCommand(sqla, connection);
                adapter = new MySqlDataAdapter(cmd);
                adapter.DeleteCommand = connection.CreateCommand();
                adapter.DeleteCommand.CommandText = sqla;

                if (MessageBox.Show("Want to delete this doctors details from database??", "confirmation messsage", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) == DialogResult.OK)
                {
                    if (adapter.DeleteCommand.ExecuteNonQuery() > 0)
                    {
                        MessageBox.Show("Seccesfully deleted");
                        retrieve2();
                        clearText();

                    }
                }
                else
                {
                    clearText();
                }
                connection.Close();
                retrieve2();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                connection.Close();

            }
        }
        private void buttonDelete_Click(object sender, EventArgs e)
        {

            if (textname.Text == "" || textphone.Text == "" || comboGender.Text == "" || cmbDepartment.Text == "")
            {
                MessageBox.Show("Select a row to be DELETED", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
            else
            {
                string selected = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
                int doctor_ID = Convert.ToInt32(selected);
                delete1(doctor_ID);
            }
        }

        private void buttonSAVEDEP_Click(object sender, EventArgs e)
        {
            if (textBoxdepartment.Text=="")
            {
                MessageBox.Show("department name MUST BE FILLED!!!");
            }
            else
            {
                string sql = "SELECT * FROM department WHERE depart_id='" + textBox1.Text + "'";
                cmd = new MySqlCommand(sql, connection);
                MySqlDataAdapter adapter = new MySqlDataAdapter(cmd);
                adapter.Fill(ds);
                int i = ds.Tables[0].Rows.Count;
                if (i > 0)
                {
                    MessageBox.Show("This deparment name already exist!!!", "ERROR MESSAGE", MessageBoxButtons.OKCancel, MessageBoxIcon.Error);
                    ds.Clear();

                }
                else
                {
                    try
                    {

                        connection.Open();
                        string query = "INSERT INTO  department( departments) VALUES('" + textBoxdepartment.Text + "' )";
                        cmd = new MySqlCommand(query, connection);
                        cmd.ExecuteNonQuery();


                        adapter = new MySqlDataAdapter("SELECT * FROM department ", connection);
                        adapter.Fill(dt);

                        MessageBox.Show("New deparment name details has been  successfully saved");

                        connection.Close();
                        department();
                      
                    }

                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }

                }
            }
        }

        private void buttonretrieve_Click(object sender, EventArgs e)
        {

        }
        private void clearText()
        {
            //textID.Clear();
            textname.Clear();
            cmbDepartment.SelectedIndex = -1;
            comboGender.SelectedIndex = -1;
            textphone.Clear();
           // textID.Focus();

        }

        private void textphone_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;

            if (!char.IsDigit(ch) && ch != 8 && ch != 46)
            {
                e.Handled = true;
            }
        }

        private void dataGridView1_MouseClick(object sender, MouseEventArgs e)
        {
            textID.Text = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
            textname.Text= dataGridView1.SelectedRows[0].Cells[1].Value.ToString();
            comboGender.Text = dataGridView1.SelectedRows[0].Cells[2].Value.ToString();
            textphone.Text = dataGridView1.SelectedRows[0].Cells[3].Value.ToString();
            cmbDepartment.Text= dataGridView1.SelectedRows[0].Cells[4].Value.ToString();
           
            
           // textID.Focus();
        }

        private void button1refresh_Click(object sender, EventArgs e)
        {
            generateID();
            clearText();
        }

        private void textphone_TextChanged(object sender, EventArgs e)
        {

        }
        private void CLEAR()
        {
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();
        }
        private void retrievelab()
        {

            MySqlCommand cmd = new MySqlCommand("SELECT * FROM test;", connection);
            try
            {
                adapter = new MySqlDataAdapter(cmd);
                adapter.SelectCommand = cmd;
                dt = new DataTable();
                adapter.Fill(dt);
                BindingSource bs = new BindingSource();

                bs.DataSource = dt;
                dataGridView2.DataSource = bs;
                adapter.Update(dt);
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }

        }
        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox3.Text == ""||textBox4.Text=="")
            {
                MessageBox.Show("ALL MUST BE FILLED!!!");
            }
            else
            {
                string sql = "SELECT * FROM test WHERE ID='" + textBox2.Text + "'";
                cmd = new MySqlCommand(sql, connection);
                MySqlDataAdapter adapter = new MySqlDataAdapter(cmd);
                adapter.Fill(ds);
                int i = ds.Tables[0].Rows.Count;
                if (i > 0)
                {
                    MessageBox.Show("This test name already exist!!!", "ERROR MESSAGE", MessageBoxButtons.OKCancel, MessageBoxIcon.Error);
                    ds.Clear();

                }
                else
                {
                    try
                    {

                        connection.Open();
                        string query = "INSERT INTO  test(  Test,Amount) VALUES('" + textBox3.Text + "','"+textBox4.Text+"')";
                        cmd = new MySqlCommand(query, connection);
                        cmd.ExecuteNonQuery();


                        adapter = new MySqlDataAdapter("SELECT * FROM test ", connection);
                        adapter.Fill(dt);

                        MessageBox.Show(" Details has been  successfully saved");

                        connection.Close();
                        retrievelab();
                        CLEAR();

                    }

                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }

                }
            }
        }
    }
}
