﻿namespace CLINIC_MAGEMENT_SOFTWARE
{
    partial class MAIN_PAGE
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelusertype = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.rECEPTIONToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mANAGEPATIENTSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cONSULTATIONToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lABToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pHARMACYToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mEDICINEToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dOCTORToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.rEPORTToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bACKUPToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.rESTOREToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.rESTOREDATAToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.button6 = new System.Windows.Forms.Button();
            this.cASHIERToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // labelusertype
            // 
            this.labelusertype.AutoSize = true;
            this.labelusertype.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelusertype.Location = new System.Drawing.Point(1318, 9);
            this.labelusertype.Name = "labelusertype";
            this.labelusertype.Size = new System.Drawing.Size(24, 16);
            this.labelusertype.TabIndex = 12;
            this.labelusertype.Text = "....";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(1241, 7);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 13);
            this.label1.TabIndex = 14;
            this.label1.Text = "label1";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Font = new System.Drawing.Font("Elephant", 8.999999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.rECEPTIONToolStripMenuItem,
            this.mANAGEPATIENTSToolStripMenuItem,
            this.cONSULTATIONToolStripMenuItem,
            this.lABToolStripMenuItem,
            this.pHARMACYToolStripMenuItem,
            this.mEDICINEToolStripMenuItem,
            this.dOCTORToolStripMenuItem,
            this.rEPORTToolStripMenuItem,
            this.bACKUPToolStripMenuItem,
            this.cASHIERToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1354, 24);
            this.menuStrip1.TabIndex = 17;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // rECEPTIONToolStripMenuItem
            // 
            this.rECEPTIONToolStripMenuItem.Name = "rECEPTIONToolStripMenuItem";
            this.rECEPTIONToolStripMenuItem.Size = new System.Drawing.Size(118, 20);
            this.rECEPTIONToolStripMenuItem.Text = "RECEPTION";
            this.rECEPTIONToolStripMenuItem.Click += new System.EventHandler(this.rECEPTIONToolStripMenuItem_Click);
            // 
            // mANAGEPATIENTSToolStripMenuItem
            // 
            this.mANAGEPATIENTSToolStripMenuItem.Name = "mANAGEPATIENTSToolStripMenuItem";
            this.mANAGEPATIENTSToolStripMenuItem.Size = new System.Drawing.Size(176, 20);
            this.mANAGEPATIENTSToolStripMenuItem.Text = "MANAGE PATIENTS";
            this.mANAGEPATIENTSToolStripMenuItem.Click += new System.EventHandler(this.mANAGEPATIENTSToolStripMenuItem_Click);
            // 
            // cONSULTATIONToolStripMenuItem
            // 
            this.cONSULTATIONToolStripMenuItem.Name = "cONSULTATIONToolStripMenuItem";
            this.cONSULTATIONToolStripMenuItem.Size = new System.Drawing.Size(150, 20);
            this.cONSULTATIONToolStripMenuItem.Text = "CONSULTATION";
            this.cONSULTATIONToolStripMenuItem.Click += new System.EventHandler(this.cONSULTATIONToolStripMenuItem_Click);
            // 
            // lABToolStripMenuItem
            // 
            this.lABToolStripMenuItem.Name = "lABToolStripMenuItem";
            this.lABToolStripMenuItem.Size = new System.Drawing.Size(57, 20);
            this.lABToolStripMenuItem.Text = "LAB ";
            this.lABToolStripMenuItem.Click += new System.EventHandler(this.lABToolStripMenuItem_Click);
            // 
            // pHARMACYToolStripMenuItem
            // 
            this.pHARMACYToolStripMenuItem.Name = "pHARMACYToolStripMenuItem";
            this.pHARMACYToolStripMenuItem.Size = new System.Drawing.Size(111, 20);
            this.pHARMACYToolStripMenuItem.Text = "PHARMACY";
            this.pHARMACYToolStripMenuItem.Click += new System.EventHandler(this.pHARMACYToolStripMenuItem_Click);
            // 
            // mEDICINEToolStripMenuItem
            // 
            this.mEDICINEToolStripMenuItem.Name = "mEDICINEToolStripMenuItem";
            this.mEDICINEToolStripMenuItem.Size = new System.Drawing.Size(105, 20);
            this.mEDICINEToolStripMenuItem.Text = "MEDICINE";
            this.mEDICINEToolStripMenuItem.Click += new System.EventHandler(this.mEDICINEToolStripMenuItem_Click);
            // 
            // dOCTORToolStripMenuItem
            // 
            this.dOCTORToolStripMenuItem.Name = "dOCTORToolStripMenuItem";
            this.dOCTORToolStripMenuItem.Size = new System.Drawing.Size(90, 20);
            this.dOCTORToolStripMenuItem.Text = "DOCTOR";
            this.dOCTORToolStripMenuItem.Click += new System.EventHandler(this.dOCTORToolStripMenuItem_Click);
            // 
            // rEPORTToolStripMenuItem
            // 
            this.rEPORTToolStripMenuItem.Name = "rEPORTToolStripMenuItem";
            this.rEPORTToolStripMenuItem.Size = new System.Drawing.Size(89, 20);
            this.rEPORTToolStripMenuItem.Text = "REPORT";
            this.rEPORTToolStripMenuItem.Click += new System.EventHandler(this.rEPORTToolStripMenuItem_Click);
            // 
            // bACKUPToolStripMenuItem
            // 
            this.bACKUPToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.rESTOREToolStripMenuItem,
            this.rESTOREDATAToolStripMenuItem});
            this.bACKUPToolStripMenuItem.Name = "bACKUPToolStripMenuItem";
            this.bACKUPToolStripMenuItem.Size = new System.Drawing.Size(87, 20);
            this.bACKUPToolStripMenuItem.Text = "BACKUP";
            this.bACKUPToolStripMenuItem.Click += new System.EventHandler(this.bACKUPToolStripMenuItem_Click);
            // 
            // rESTOREToolStripMenuItem
            // 
            this.rESTOREToolStripMenuItem.Name = "rESTOREToolStripMenuItem";
            this.rESTOREToolStripMenuItem.Size = new System.Drawing.Size(202, 22);
            this.rESTOREToolStripMenuItem.Text = "BACKUP DATA";
            this.rESTOREToolStripMenuItem.Click += new System.EventHandler(this.rESTOREToolStripMenuItem_Click);
            // 
            // rESTOREDATAToolStripMenuItem
            // 
            this.rESTOREDATAToolStripMenuItem.Name = "rESTOREDATAToolStripMenuItem";
            this.rESTOREDATAToolStripMenuItem.Size = new System.Drawing.Size(202, 22);
            this.rESTOREDATAToolStripMenuItem.Text = "RESTORE DATA";
            this.rESTOREDATAToolStripMenuItem.Click += new System.EventHandler(this.rESTOREDATAToolStripMenuItem_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::CLINIC_MAGEMENT_SOFTWARE.Properties.Resources.outpatient;
            this.pictureBox1.Location = new System.Drawing.Point(2, 107);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(1361, 686);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 15;
            this.pictureBox1.TabStop = false;
            // 
            // button6
            // 
            this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button6.Font = new System.Drawing.Font("Elephant", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button6.Image = global::CLINIC_MAGEMENT_SOFTWARE.Properties.Resources.logout;
            this.button6.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button6.Location = new System.Drawing.Point(1094, 1);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(141, 24);
            this.button6.TabIndex = 8;
            this.button6.Text = "LOGOUT\r\n";
            this.button6.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // cASHIERToolStripMenuItem
            // 
            this.cASHIERToolStripMenuItem.Name = "cASHIERToolStripMenuItem";
            this.cASHIERToolStripMenuItem.Size = new System.Drawing.Size(94, 20);
            this.cASHIERToolStripMenuItem.Text = "CASHIER";
            this.cASHIERToolStripMenuItem.Click += new System.EventHandler(this.cASHIERToolStripMenuItem_Click);
            // 
            // MAIN_PAGE
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkSlateGray;
            this.ClientSize = new System.Drawing.Size(1354, 733);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.labelusertype);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.menuStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "MAIN_PAGE";
            this.Text = "MAIN_PAGE";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.MAIN_PAGE_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Label labelusertype;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem rECEPTIONToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mANAGEPATIENTSToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cONSULTATIONToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem lABToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pHARMACYToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mEDICINEToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dOCTORToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem rEPORTToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bACKUPToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem rESTOREToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem rESTOREDATAToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cASHIERToolStripMenuItem;
    }
}