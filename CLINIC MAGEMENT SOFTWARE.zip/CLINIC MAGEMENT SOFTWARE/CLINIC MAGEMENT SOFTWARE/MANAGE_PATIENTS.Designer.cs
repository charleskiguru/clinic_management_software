﻿namespace CLINIC_MAGEMENT_SOFTWARE
{
    partial class MANAGE_PATIENTS
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.comboBox2BLOOD = new System.Windows.Forms.ComboBox();
            this.label15 = new System.Windows.Forms.Label();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.comboGender = new System.Windows.Forms.ComboBox();
            this.label11 = new System.Windows.Forms.Label();
            this.comboCounty = new System.Windows.Forms.ComboBox();
            this.textPhone = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.textName = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.textId = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.button1refresh = new System.Windows.Forms.Button();
            this.button3Print = new System.Windows.Forms.Button();
            this.button2Delete = new System.Windows.Forms.Button();
            this.button1Update = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.SuspendLayout();
            // 
            // comboBox2BLOOD
            // 
            this.comboBox2BLOOD.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.comboBox2BLOOD.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox2BLOOD.FormattingEnabled = true;
            this.comboBox2BLOOD.Items.AddRange(new object[] {
            "A",
            "B",
            "AB",
            "O"});
            this.comboBox2BLOOD.Location = new System.Drawing.Point(493, 121);
            this.comboBox2BLOOD.Name = "comboBox2BLOOD";
            this.comboBox2BLOOD.Size = new System.Drawing.Size(214, 21);
            this.comboBox2BLOOD.TabIndex = 62;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(393, 121);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(86, 13);
            this.label15.TabIndex = 61;
            this.label15.Text = "BLOOD GROUP";
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.Location = new System.Drawing.Point(493, 67);
            this.dateTimePicker2.MinDate = new System.DateTime(1900, 1, 1, 0, 0, 0, 0);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(222, 20);
            this.dateTimePicker2.TabIndex = 60;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(393, 67);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(89, 13);
            this.label13.TabIndex = 59;
            this.label13.Text = "DATE OF BIRTH";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(17, 186);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(53, 13);
            this.label12.TabIndex = 58;
            this.label12.Text = "GENDER";
            // 
            // comboGender
            // 
            this.comboGender.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboGender.FormattingEnabled = true;
            this.comboGender.Items.AddRange(new object[] {
            "SELECT GENDER",
            "FEMALE",
            "MALE"});
            this.comboGender.Location = new System.Drawing.Point(114, 178);
            this.comboGender.Name = "comboGender";
            this.comboGender.Size = new System.Drawing.Size(252, 21);
            this.comboGender.TabIndex = 57;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(397, 20);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(52, 13);
            this.label11.TabIndex = 56;
            this.label11.Text = "COUNTY";
            // 
            // comboCounty
            // 
            this.comboCounty.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboCounty.FormattingEnabled = true;
            this.comboCounty.Items.AddRange(new object[] {
            "NAKURU",
            "NAIROBI",
            "BUSIA",
            "KAKAMEGA",
            "UASIN GISHU",
            "MOMBASA"});
            this.comboCounty.Location = new System.Drawing.Point(493, 12);
            this.comboCounty.Name = "comboCounty";
            this.comboCounty.Size = new System.Drawing.Size(214, 21);
            this.comboCounty.TabIndex = 55;
            // 
            // textPhone
            // 
            this.textPhone.Location = new System.Drawing.Point(114, 127);
            this.textPhone.MaxLength = 10;
            this.textPhone.Name = "textPhone";
            this.textPhone.Size = new System.Drawing.Size(252, 20);
            this.textPhone.TabIndex = 52;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(9, 134);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(95, 13);
            this.label9.TabIndex = 51;
            this.label9.Text = "PHONE NUMBER";
            // 
            // textName
            // 
            this.textName.Location = new System.Drawing.Point(114, 72);
            this.textName.Name = "textName";
            this.textName.Size = new System.Drawing.Size(252, 20);
            this.textName.TabIndex = 50;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(12, 79);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(67, 13);
            this.label8.TabIndex = 49;
            this.label8.Text = "FULL NAME";
            // 
            // textId
            // 
            this.textId.Location = new System.Drawing.Point(114, 16);
            this.textId.Name = "textId";
            this.textId.ReadOnly = true;
            this.textId.Size = new System.Drawing.Size(252, 20);
            this.textId.TabIndex = 48;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(14, 30);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(67, 13);
            this.label7.TabIndex = 47;
            this.label7.Text = "PATIENT ID";
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.button1refresh);
            this.panel1.Controls.Add(this.button3Print);
            this.panel1.Controls.Add(this.button2Delete);
            this.panel1.Controls.Add(this.button1Update);
            this.panel1.Font = new System.Drawing.Font("Elephant", 8.999999F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel1.Location = new System.Drawing.Point(756, 5);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(184, 217);
            this.panel1.TabIndex = 46;
            // 
            // button1refresh
            // 
            this.button1refresh.BackColor = System.Drawing.Color.Yellow;
            this.button1refresh.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1refresh.ForeColor = System.Drawing.Color.Black;
            this.button1refresh.Location = new System.Drawing.Point(26, 0);
            this.button1refresh.Name = "button1refresh";
            this.button1refresh.Size = new System.Drawing.Size(137, 40);
            this.button1refresh.TabIndex = 3;
            this.button1refresh.Text = "VIEW";
            this.button1refresh.UseVisualStyleBackColor = false;
            this.button1refresh.Click += new System.EventHandler(this.button1refresh_Click_1);
            // 
            // button3Print
            // 
            this.button3Print.BackColor = System.Drawing.Color.Yellow;
            this.button3Print.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3Print.ForeColor = System.Drawing.Color.Black;
            this.button3Print.Location = new System.Drawing.Point(33, 105);
            this.button3Print.Name = "button3Print";
            this.button3Print.Size = new System.Drawing.Size(130, 40);
            this.button3Print.TabIndex = 2;
            this.button3Print.Text = "CLEAR";
            this.button3Print.UseVisualStyleBackColor = false;
            this.button3Print.Click += new System.EventHandler(this.button3Print_Click_1);
            // 
            // button2Delete
            // 
            this.button2Delete.BackColor = System.Drawing.Color.Yellow;
            this.button2Delete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2Delete.ForeColor = System.Drawing.Color.Black;
            this.button2Delete.Image = global::CLINIC_MAGEMENT_SOFTWARE.Properties.Resources.delete_300x300;
            this.button2Delete.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button2Delete.Location = new System.Drawing.Point(33, 158);
            this.button2Delete.Name = "button2Delete";
            this.button2Delete.Size = new System.Drawing.Size(130, 42);
            this.button2Delete.TabIndex = 1;
            this.button2Delete.Text = "DELETE";
            this.button2Delete.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button2Delete.UseVisualStyleBackColor = false;
            this.button2Delete.Click += new System.EventHandler(this.button2Delete_Click_1);
            // 
            // button1Update
            // 
            this.button1Update.BackColor = System.Drawing.Color.Yellow;
            this.button1Update.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1Update.ForeColor = System.Drawing.Color.Black;
            this.button1Update.Location = new System.Drawing.Point(26, 56);
            this.button1Update.Name = "button1Update";
            this.button1Update.Size = new System.Drawing.Size(137, 34);
            this.button1Update.TabIndex = 0;
            this.button1Update.Text = "UPDATE";
            this.button1Update.UseVisualStyleBackColor = false;
            this.button1Update.Click += new System.EventHandler(this.button1Update_Click_1);
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(6, 54);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(218, 20);
            this.textBox1.TabIndex = 64;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.textBox1);
            this.panel2.Location = new System.Drawing.Point(946, 63);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(226, 90);
            this.panel2.TabIndex = 63;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.Red;
            this.label1.Location = new System.Drawing.Point(29, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(151, 13);
            this.label1.TabIndex = 66;
            this.label1.Text = "SEARCH BY PATIENT NAME";
            // 
            // dataGridView2
            // 
            this.dataGridView2.AllowUserToAddRows = false;
            this.dataGridView2.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.Blue;
            this.dataGridView2.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView2.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView2.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.dataGridView2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.Blue;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView2.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(-2, 228);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.ReadOnly = true;
            this.dataGridView2.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView2.Size = new System.Drawing.Size(1183, 242);
            this.dataGridView2.TabIndex = 65;
            this.dataGridView2.MouseCaptureChanged += new System.EventHandler(this.dataGridView2_MouseCaptureChanged);
            // 
            // MANAGE_PATIENTS
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkSlateGray;
            this.ClientSize = new System.Drawing.Size(1176, 469);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.comboBox2BLOOD);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.dateTimePicker2);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.comboGender);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.comboCounty);
            this.Controls.Add(this.textPhone);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.textName);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.textId);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.panel1);
            this.Name = "MANAGE_PATIENTS";
            this.Text = "MANAGE_PATIENTS";
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox comboBox2BLOOD;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.ComboBox comboGender;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ComboBox comboCounty;
        private System.Windows.Forms.TextBox textPhone;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox textName;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox textId;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button button1refresh;
        private System.Windows.Forms.Button button3Print;
        private System.Windows.Forms.Button button2Delete;
        private System.Windows.Forms.Button button1Update;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.Label label1;
    }
}