﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
namespace CLINIC_MAGEMENT_SOFTWARE
{
    public partial class LAB : Form
    {
        static string conString = "server=localhost;database=hospital;Uid=root;Password=;";
        MySqlConnection connection = new MySqlConnection(conString);
        MySqlCommand cmd;
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        MySqlDataReader dr;
        MySqlDataAdapter adapter;
        public LAB()
        {
            InitializeComponent();
  
         


        }

        private void btnSAVE_Click(object sender, EventArgs e)
        {
            if (textboxSearch.Text == "" || txtText.Text == "" || txtResult.Text == ""||dateTimePicker1.Text=="")
            {
                MessageBox.Show("Fill all the textboxes ", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
            else
            {
                string selected = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
                int patient_Id = Convert.ToInt32(selected);

                update2(patient_Id, txtText.Text, txtResult.Text,dateTimePicker1.Text);
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
           
        }
        private void update2(int patient_Id,string test,string lab_result,string date)
        {
            string sql = "UPDATE lab SET test= '" + test + "',lab_result='" + lab_result + "',date='"+date+ "' WHERE patient_Id= '" + patient_Id + "' AND date='"+dateTimePicker1.Text+"' ";
            cmd = new MySqlCommand(sql, connection);

            try
            {
                connection.Open();
                adapter = new MySqlDataAdapter(cmd);
                adapter.UpdateCommand = connection.CreateCommand();
                adapter.UpdateCommand.CommandText = sql;

                if (MessageBox.Show("Do you want to save this patients details??", "confirmation message", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    if (adapter.UpdateCommand.ExecuteNonQuery() > 0)
                    {
                        MessageBox.Show("Succesfully Saved");
                        retrievelab();

                        connection.Close();

                    }
                }

                else
                {

                }
                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                connection.Close();
            }
        }
        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (textboxSearch.Text == "" || txtText.Text == "" || txtResult.Text == "")
            {
                MessageBox.Show("Select a row to be DELETED", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
            else
            {
                string selected = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
                int patient_Id = Convert.ToInt32(selected);
                delete2(patient_Id);


            }
        }
        private void delete2(int patient_Id)
        {
            string sql = "DELETE FROM lab WHERE patient_Id=" + patient_Id + "  AND date='"+dateTimePicker1.Text+"'";
            try
            {
                connection.Open();
                cmd = new MySqlCommand(sql, connection);
                adapter = new MySqlDataAdapter(cmd);
                adapter.DeleteCommand = connection.CreateCommand();
                adapter.DeleteCommand.CommandText = sql;

                if (MessageBox.Show("Want to delete this patients lab details from database??", "confirmation messsage", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) == DialogResult.OK)
                {
                    if (adapter.DeleteCommand.ExecuteNonQuery() > 0)
                    {
                        MessageBox.Show("Seccesfully deleted");
                      

                    }
                }
                else
                {
                    
                }
                connection.Close();


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                connection.Close();

            }
        }
      
       
        private void retrievelab()
        {

            MySqlCommand cmd = new MySqlCommand("SELECT patient_Id,test,lab_result,date,lab_charges FROM lab;", connection);
            try
            {
                adapter = new MySqlDataAdapter(cmd);
                adapter.SelectCommand = cmd;
                dt = new DataTable();
                adapter.Fill(dt);
                BindingSource bs = new BindingSource();

                bs.DataSource = dt;
                dataGridView1.DataSource = bs;
                adapter.Update(dt);
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }

        }

        private void dataGridView1_MouseClick(object sender, MouseEventArgs e)
        {
            textboxSearch.Text = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
            txtText.Text = dataGridView1.SelectedRows[0].Cells[1].Value.ToString();
            txtResult.Text = dataGridView1.SelectedRows[0].Cells[2].Value.ToString();
          //  dateTimePicker1.Text = dataGridView1.SelectedRows[0].Cells[3].Value.ToString();
        
            
           
        }

        private void combosId_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (textboxSearch.Text == "" || txtText.Text == "" || txtResult.Text == "")
            {
                MessageBox.Show("All field must be filled before saving");
            }
            else
            {

                connection.Open();
                string query = "INSERT INTO  lab(patient_Id,test,lab_result) VALUES('" + textboxSearch.Text + "','" + txtText.Text + "','" + txtResult.Text + "' )";
                cmd = new MySqlCommand(query, connection);
                cmd.ExecuteNonQuery();


                adapter = new MySqlDataAdapter("SELECT * FROM lab ", connection);
                adapter.Fill(dt);

                MessageBox.Show("Patient lab  details has been  successfully saved");

                connection.Close();


            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textboxSearch.Text == "")
            {
                MessageBox.Show("Enter the patient ID");

            }
            else
            {
                connection = new MySqlConnection(conString);
                connection.Open();
                adapter = new MySqlDataAdapter("SELECT patient_Id,test,lab_result,lab_charges FROM lab WHERE patient_Id = '" + textboxSearch.Text + "' AND date='"+dateTimePicker1.Text+"' ", connection);
                dt = new DataTable();
                adapter.Fill(dt);

               
              dataGridView1.DataSource = dt;
                connection.Close();
                textboxSearch.Clear();
            }

        }

        private void button1_Click_1(object sender, EventArgs e)
        {

        }
    }
}
