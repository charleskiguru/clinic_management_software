-- phpMyAdmin SQL Dump
-- version 3.5.2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Aug 03, 2018 at 05:44 PM
-- Server version: 5.5.25a
-- PHP Version: 5.4.4

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `hospital`
--

-- --------------------------------------------------------

--
-- Table structure for table `billing`
--

CREATE TABLE IF NOT EXISTS `billing` (
  `patient_Id` int(100) NOT NULL,
  `date` varchar(200) NOT NULL,
  `lab_charge` varchar(400) NOT NULL,
  `medicine_charges` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `department`
--

CREATE TABLE IF NOT EXISTS `department` (
  `depart_id` int(11) NOT NULL AUTO_INCREMENT,
  `departments` varchar(200) NOT NULL,
  PRIMARY KEY (`depart_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `department`
--

INSERT INTO `department` (`depart_id`, `departments`) VALUES
(1, 'DENTIST'),
(2, 'PATHOLOGIST'),
(3, 'RADIOLOGY'),
(4, 'CARDIOLOGY'),
(5, 'GYNECOLOGIST'),
(6, 'NEUROLOGIST'),
(7, 'ONCOLOGY');

-- --------------------------------------------------------

--
-- Table structure for table `doctor`
--

CREATE TABLE IF NOT EXISTS `doctor` (
  `doctor_ID` int(11) NOT NULL AUTO_INCREMENT,
  `doctor_name` varchar(200) NOT NULL,
  `gender` varchar(200) NOT NULL,
  `phone` varchar(200) NOT NULL,
  `department` varchar(200) NOT NULL,
  PRIMARY KEY (`doctor_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `doctor`
--

INSERT INTO `doctor` (`doctor_ID`, `doctor_name`, `gender`, `phone`, `department`) VALUES
(3, 'chebu kati  ', 'FEMALE', '0777687996', 'ONCOLOGY'),
(4, 'metto  black  ', 'FEMALE', '07123455', 'RADIOLOGY'),
(5, 'pak chan ', 'MALE', '0788766434', 'DENTIST'),
(6, 'jane gathuma ', 'MALE', '0676888890', 'RADIOLOGY'),
(7, 'hannam kaim ', 'FEMALE', '023347586', 'GYNECOLOGIST'),
(8, 'pert cheptoo ', 'MALE', '07234099', 'ONCOLOGY');

-- --------------------------------------------------------

--
-- Table structure for table `lab`
--

CREATE TABLE IF NOT EXISTS `lab` (
  `patient_Id` int(11) NOT NULL,
  `test` varchar(200) NOT NULL,
  `lab_result` varchar(200) NOT NULL,
  `date` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `lab`
--

INSERT INTO `lab` (`patient_Id`, `test`, `lab_result`, `date`) VALUES
(1, 'blood', 'AAAA bactria found', 'Friday, August 3, 2018');

-- --------------------------------------------------------

--
-- Table structure for table `medicine`
--

CREATE TABLE IF NOT EXISTS `medicine` (
  `medicine_id` int(11) NOT NULL AUTO_INCREMENT,
  `medicine_name` varchar(200) NOT NULL,
  `medicine_type` varchar(300) NOT NULL,
  `price` varchar(200) NOT NULL,
  PRIMARY KEY (`medicine_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `medicine`
--

INSERT INTO `medicine` (`medicine_id`, `medicine_name`, `medicine_type`, `price`) VALUES
(2, 'AA med  ', 'TABLET', '20'),
(3, 'bruffen  ', 'SYRUP', '100'),
(4, 'malaria queen  ', 'POWDER', '90'),
(5, 'panadol  ', 'TABLET', '10'),
(6, 'mara moja  ', 'TABLET', '50');

-- --------------------------------------------------------

--
-- Table structure for table `patients`
--

CREATE TABLE IF NOT EXISTS `patients` (
  `patient_Id` int(100) NOT NULL,
  `fullname` varchar(200) NOT NULL,
  `phone` varchar(200) NOT NULL,
  `county` varchar(200) NOT NULL,
  `gender` varchar(200) NOT NULL,
  `date_of_birth` varchar(200) NOT NULL,
  `blood_group` varchar(100) NOT NULL,
  PRIMARY KEY (`patient_Id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `patients`
--

INSERT INTO `patients` (`patient_Id`, `fullname`, `phone`, `county`, `gender`, `date_of_birth`, `blood_group`) VALUES
(1, 'paul chege ', '0717537477', 'MOMBASA', 'MALE', 'Friday, February 18, 1994', 'O');

-- --------------------------------------------------------

--
-- Table structure for table `patient_info`
--

CREATE TABLE IF NOT EXISTS `patient_info` (
  `patient_Id` int(11) NOT NULL,
  `date` varchar(150) NOT NULL,
  `department` varchar(200) NOT NULL,
  `doctor_ID` varchar(250) NOT NULL,
  `bloodpressure` varchar(200) NOT NULL,
  `complaints` varchar(300) NOT NULL,
  `disease` varchar(250) NOT NULL,
  `medicine` varchar(300) NOT NULL,
  `test` varchar(200) NOT NULL,
  `lab_result` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `patient_info`
--

INSERT INTO `patient_info` (`patient_Id`, `date`, `department`, `doctor_ID`, `bloodpressure`, `complaints`, `disease`, `medicine`, `test`, `lab_result`) VALUES
(1, 'Friday, August 3, 2018', 'DENTIST', '3', '560', 'headache and vomiting', 'ulcers ', 'bruffen and pandol', 'blood', 'AAAA bactria found');

-- --------------------------------------------------------

--
-- Table structure for table `pharmacy`
--

CREATE TABLE IF NOT EXISTS `pharmacy` (
  `patient_Id` int(100) NOT NULL,
  `date` varchar(300) NOT NULL,
  `totalprice` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `test`
--

CREATE TABLE IF NOT EXISTS `test` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Test` varchar(150) NOT NULL,
  `Amount` varchar(200) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `test`
--

INSERT INTO `test` (`ID`, `Test`, `Amount`) VALUES
(1, 'blood', '200'),
(2, 'urine', '300');

-- --------------------------------------------------------

--
-- Table structure for table `treatment`
--

CREATE TABLE IF NOT EXISTS `treatment` (
  `patient_Id` int(100) NOT NULL,
  `date` varchar(200) NOT NULL,
  `disease` varchar(200) NOT NULL,
  `medicine` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id` int(200) NOT NULL AUTO_INCREMENT,
  `usertype` varchar(200) NOT NULL,
  `username` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `usertype`, `username`, `password`) VALUES
(1, 'RECEPTIONIST', 'reception', '1234'),
(2, 'DOCTOR', 'doctor', '1234'),
(3, 'ADMINISTRATOR', 'admin', '1234');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
